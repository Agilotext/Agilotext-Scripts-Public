# Plan récapitulatif : backend « identique à Marvin » vs Anon2 (Agilotext)

**Document interne** — avril 2026 — à usage produit / technique.  
**Références** : [MARVIN_BACKEND_DECODED.md](../marvin_intel/MARVIN_BACKEND_DECODED.md), [MARVIN_CLONE_BLUEPRINT_2026.md](../marvin_intel/MARVIN_CLONE_BLUEPRINT_2026.md), [anon2_for_cursor.md](anon2_for_cursor.md).

---

## 1. Objectif de ce plan récap

Expliquer en une lecture :

1. **Ce qu’implique** un backend « à l’identique » du *paradigme* observé chez Marvin (SaaS documentaire, markdown intermédiaire, NER, régions, temps réel, facturation).
2. **En quoi Anon2 / l’existant Agilotext** s’en rapproche déjà et **où** ça diverge.
3. **Un plan d’alignement** par couches (API, job model, pipeline texte, spatial, facturation) sans confondre *copie produit* et *niveau de maturité technique*.

> Marvin n’expose pas son code source. Tout ce qui concerne **leur** API est issu d’**audit passif** (HAR, schéma inféré). Ici, on parle d’un **modèle de référence** « type Marvin » pour cadrer les travaux Anon2.

---

## 2. Backend « type Marvin » (modèle de référence)

| Couche | Rôle | Technologies typiques (observé / reproductible) |
|--------|------|--------------------------------|
| **Front** | App web, éditeur, i18n | Next.js (App Router), composants RSC, assets optimisés |
| **BaaS / API** | Auth, comptes, **jobs** d’anonymisation, **fichiers**, temps réel | **PocketBase** (ou équivalent BaaS + stockage + règles) |
| **Traitement** | Extraction -> texte/MD -> tokenizer/sanitizer -> **NER** -> `markdownOutput` + **`markdownRegions`** (JSON) | Service interne type **« Brain »** (workers Python, file GPU, queue Redis) |
| **Paiement & compta** | Abonnement / crédits | **Stripe** + webhooks, collection dédiée côté BaaS |
| **Observabilité & marketing** | Analytics, campagnes | PostHog (souvent proxifié), tag pub (ex. Google Ads) |

**Pipeline métier (ordre logique, tel que déduit des champs `app_calls`)** :

```
Fichier uploadé
  -> extractor (vers markdown / texte riche, durées comptabilisées)
  -> tokenizedInput / sanitizedInput
  -> analyzer (NER, occurrences, regions spatiales/structurelles)
  -> markdownOutput + crédits consommés
```

**Trois idées structurantes** :

1. **Un seul enregistrement “job”** côté API (`app_calls` équivalent) avec état, fichiers liés, progression observable (**SSE**).
2. **Le texte de travail est du markdown (ou texte normalisé)** : le NER ne tourne pas “à l’aveugle” sur le PDF brut, il a une couche unifiée.
3. **Les coordonnées** (pour surlignage / caviardage) sortent en **`markdownRegions`** (JSON côté stockage), pas seulement des offsets plats.

```mermaid
flowchart LR
  U[Utilisateur] --> W[App_Web]
  W --> PB[PocketBase_jobs_et_fichiers]
  W --> R[SSE_realtime]
  PB --> Q[Queue]
  Q --> B[Worker_BRAIN_Python]
  B --> PB
  PB --> St[Stripe]
```

---

## 3. Backend Anon2 / déploiement Agilotext (état documenté)

Anon2 n’est **pas** un seul binaire : c’est un **assemblage** documenté autour d’un moteur Python (Presidio, GLiNER, validateurs FR, OCR PaddleOCR prévu) et, selon le chemin, d’une **couche Java** existante ou autonome.

### 3.1 Moteur Python (package `anon2`, daemon)

- **Rôle** : détection PII, fusion regex + NER, **contrat fichier** attendu par le backend Java Agilotext (fichiers `*_nodes_lines.json.txt` / `*_pdf_spans.json.txt`, etc.).
- **Briques** : validateurs NIR, SIREN, SIRET, TVA, IBAN, BIC, etc. ; branchements possibles **Presidio**, **GLiNER**, **PaddleOCR** pour scans.
- **Mode** : souvent **traitement par dépôt / fichiers** (pas d’équivalent PocketBase intégré au même endroit).

### 3.2 Intégration Java Agilotext (héritage)

- **PDF** : extraction texte + positions (PDFBox, redaction spatiale, classes type `PdfNativeVisualRedactor`, etc.).
- **Office** : POI, remplacements, métadonnées.
- **Pont** : le moteur Python **retourne des spans** ; Java applique caviardage / remplacements. C’est **aligné conceptuellement** sur « texte + zones », mais le **plumbing** n’est pas le même qu’un `app_calls` + SSE unifié.

### 3.3 Projet **anon-java** (parcours parallèle documenté)

- **Java 17** autonome : daemon **inbox / outbox / archive / error** sur disque.
- **Pas de base de données** : pas d’équivalent SaaS.
- **Détecteur** : HTTP `127.0.0.1:8181` — `POST /v1/spans`, `POST /v1/replace-lines`.
- **Limites V1** : PDF **texte natif** seulement sinon erreur `SCANNED_PDF_OCR_REQUIRED` (OCR = charge côté moteur Python, pas intégré dans le jar par défaut).

**En une phrase** : Anon2/anon-java, c’est **détection découplée + orchestration fichier** ; Marvin-type, c’est **BaaS + job unique + progression temps réel + markdown + regions stockées côté service**.

---

## 4. Tableau comparatif (backend)

| Sujet | Modèle « type Marvin » | Anon2 / stack Agilotext (documenté) |
|--------|------------------------|--------------------------------------|
| **Cœur API** | PocketBase (REST, auth, files, règles) | **Pas** d’équivalent unique : **Java** Agilotext +/daemon **Python** + contrats fichiers |
| **Modèle de job** | Enregistrement `app_calls` (statuts, champs normalisés) | Jobs **implicites** (fichiers traités) ou intégration **dans** la base produit existante (autre modèle) |
| **Couche intermédiaire** | **Markdown** + fichiers `markdown_input/output` | Texte/ spans / lignes ; **passage explicite MD-first** moins centralisé dans la doc Anon2 |
| **Régions spatiales** | `markdownRegions` (JSON) **persisté** côté API | Spans + PDF positions **côté Java** ; **JSON de regions “produit unifié”** à consolider si on veut la même expérience éditeur |
| **Temps réel** | **SSE** `/api/realtime` sur la collection | Polling, fichiers, ou bus interne **selon** intégration (à cartographier sur le monolithe) |
| **Paiement** | **Stripe** couplé au BaaS | **À brancher** au produit (Memberstack, autre) — **pas** le même ancrage que `StripeSessions` PocketBase |
| **Workers lourds** | Service **Brain** + queue (GPU) | Même **besoin** (GPU, queue) si les volumes sont SaaS ; aujourd’hui plutôt **déploiement serveur** type **systemd** (Java + Python) |
| **Identité / multi-tenant** | `users` + règles par record | Métier Agilotext existant (à aligner) |
| **Ontologie** | 18 clés (PR, MAIL, …, CP) | **Proche** si la config Anon2 **figure** les mêmes types ; **vérifier** la liste stricte et les alias |

---

## 5. « Faire à l’identique » le backend : que faut-il vraiment ?

Pour atteindre un **comportement équivalent** (pas une copie de code), il faut **cinq blocs** :

1. **API de jobs** : création, listage filtré par utilisateur, statuts, erreurs, **jamais** d’ID devinable sans droit.
2. **Storage unifié** : entrée + sorties + `regions` + traces de coût (credits) — **S3** ou files PocketBase avec URLs **signées courtes** (pas de jetons en `localStorage` — leçon audit F3).
3. **Pipeline** : *extract* -> (option) *tokenize/sanitize* -> *NER* -> *pseudonymisation* -> *render* — **même enchaînement** que le blueprint Marvin.
4. **Worker asynchrone** : Redis (ou file) + processus Python **séparé** du serv HTTP ; GPU optionnel.
5. **Canal de progression** : **SSE** ou **WebSocket** filtré par `user` (leçon F9).

**Ce qui n’est pas « backend »** mais produit : Next.js, landing, PostHog (à durcir F8) — comptent pour l’**identité** SaaS, pas pour l’anonymisation intrinsèque.

---

## 6. Écarts concrets : Anon2 aujourd’hui vs cible « Marvin-like »

| Capacité | Anon2 (selon doc) | Action pour se rapprocher |
|----------|--------------------|---------------------------|
| MD intermédiaire unique | Partiel (focus spans / moteur) | Introduire une étape **export MD canonique** par document dans le worker |
| Fichier `*regions*.json` unifié | Spans côté Java ; **agrégat “regions produit”** variable | **Normaliser** un schéma `markdownRegions`-compatible côté sortie moteur |
| Queue + worker dédié | Possible en systemd, pas le même modèle qu’un job SaaS | **Service** `worker` + Redis + idempotence |
| Temps réel | Non décrit comme SSE unique | Exposer **SSE** (ou message broker) sur **jobId** côté API Agilotext |
| 18 entités exactes | Configurable (Presidio/GLiNER) | **Geler** la taxonomie et les tests de non-régression par type |
| Markdown-first editor UX | Côté Marvin **fort** | Côté Agilotext : **aligner** le viewer/éditeur sur **MD** + surcouche entités (effort **front** autant que back) |

---

## 7. Plan d’alignement (4 phases) — propos opérationnel

**Phase A — Donnée et contrat (2–3 sprints)**  
- Définir un **schéma JSON unique** (entrée extraction, `regions`, sortie) partagé Java ↔ Python, **inspiré** de `markdownInput` / `markdownOutput` / `markdownRegions`.  
- Geler la liste **18 types** + mapping interne (alias legacy).

**Phase B — Orchestration (2 sprints)**  
- File d’attente (Redis) + **worker** idempotent.  
- Idempotence `job_id` + reprise sur crash.

**Phase C — API « job » côté Agilotext (3 sprints)**  
- Endpoints REST (ou intégration couche actuelle) : `create job`, `get status`, `get result`, **règles d’autorisation** strictes.  
- **SSE** (ou équivalent) pour le suivi, **filtre tenant/user**.

**Phase D — Parité “Brain” (continu)**  
- **GLiNER + Presidio + validateurs** : même stack que le blueprint.  
- **OCR** (PaddleOCR) sur file dédiée pour scans.  
- **F1** / SSIM : jeux d’**essai** (comme en annexe A3 du blueprint) **côté interne**.

**Phase E — Paiement & conformité (hors cœur anonymisation mais SaaS)**  
- Aligner crédits / Stripe avec le modèle économique voulu ; **DPA** ; pas de fuite d’**analytics** sur contenu (F8).

---

## 8. Rendu PDF à l’identique : comment Marvin **n’abime pas** la facture (et comment faire pareil ou mieux)

> **Idée clé** : Marvin **ne re-rend pas** le PDF à partir du markdown. Le markdown sert à l’**éditeur**, à la **NER** et à l’**affichage** des occurrences. Le PDF de sortie, lui, est le **PDF d’origine** auquel on **applique localement** des **caviardages spatiaux** (et un nettoyage métadonnées). On **ne reconstruit pas** la facture — on la **modifie chirurgicalement**.
>
> C’est ce qui permet à un PDF de **facture** ou de **contrat** de revenir avec **exactement la même structure**, les mêmes polices, mêmes logos, mêmes tableaux, mêmes mises en page, etc. Re-render depuis du Markdown casserait tout cela.

### 8.1 Ce que fait Marvin (paradigme inféré et reproductible)

Deux pipelines **parallèles**, qui partagent un même **catalogue d’occurrences** :

```mermaid
flowchart LR
  PDF[PDF_origine] --> EX[Extracteur_texte_positions_PDF]
  EX --> MD[Markdown_canonique]
  EX --> POS[Index_positions_glyphes]
  MD --> NER[Detection_PII_18_types]
  NER --> OCC[Occurrences_avec_groupes]
  OCC --> MAP[Mapping_MD_vers_PDF]
  POS --> MAP
  MAP --> REG[markdownRegions_JSON_par_page_bbox]
  REG --> RED[Redaction_locale_PDF]
  PDF --> RED
  RED --> PDFOUT[PDF_anonymise_meme_structure]
```

- **Pipeline A — sémantique** : `PDF -> Markdown -> NER -> Occurrences`. Sert l’**éditeur** (vue côté à côté), la **liste d’entités**, le regroupement.
- **Pipeline B — spatial** : on conserve l’**index** des positions (glyphes / mots / tableaux / images) du PDF d’origine, sans le re-rendre.
- **Pont A↔B (le secret)** : pour chaque **occurrence** trouvée dans le markdown, on retrouve **les glyphes/mots du PDF** qui l’ont produite, et on en déduit une ou plusieurs **bbox/polygones** par **page**. Ce résultat est persisté en `markdownRegions` (JSON spatial).
- **Sortie PDF** : on ouvre le PDF d’origine, on **annote en rédaction** chaque bbox (avec couleur ou rectangle plein), on **applique** la rédaction (les glyphes en dessous sont retirés du flux de contenu), on **purge** la couche texte intéressée, on **nettoie** les métadonnées et **liens**, on **resauvegarde**. Aucune re-impression depuis Markdown.

### 8.2 Recette de cuisine (ingrédients, étapes, contrôles)

#### Ingrédients

- **Extraction PDF avec positions** : PDFBox (Java) ou PyMuPDF (Python). Récupérer pour chaque mot : `page`, `text`, `bbox = [x0, y0, x1, y1]`, et **offsets** dans une **vue texte unifiée**.
- **Vue texte unifiée** : reconstituer un **flux** « page après page, ligne après ligne », en gardant un **mapping** `flux_offset -> (page, word_id, bbox)`.
- **Markdown canonique** (optionnel mais recommandé) : générer un MD à partir du flux unifié pour l’éditeur — **sans** servir de source pour la sortie PDF.
- **NER** + **regex** + **validateurs** (Presidio, GLiNER, IBAN, NIR, …) : produit des **spans** sur le **flux unifié** (ou sur le MD si le MD garde un mapping bijectif vers le flux).
- **Mapping spans -> bboxes** : pour chaque span `(start, end)`, récupérer la **liste de mots** couverts ; pour chaque mot, sa **bbox** ; **fusionner** les bboxes contiguës par ligne pour des rectangles propres ; un span peut générer **N rectangles** (multi-ligne).
- **Rédaction en place** : `add_redact_annot(bbox)` puis `apply_redactions()` (PyMuPDF) ou `PDFRedactionTool` côté PDFBox/iText. Cela **supprime les glyphes** sous le rectangle (pas un simple recouvrement) — un copier-coller du PDF anonymisé ne ramènera **pas** la donnée originale.

#### Étapes (ordre strict)

1. **Détecter le format**.
   - PDF **textuel** : OK pour pipeline natif.
   - PDF **scanné** ou pages images : router vers OCR (PaddleOCR) qui doit produire des **mots avec bbox** (et non un texte brut). On reprend ensuite le **même** flux de mapping.
2. **Extraire** mots + bbox par page. Construire le **flux unifié** + table de mapping.
3. **Générer** le markdown canonique (vue éditeur).
4. **Détecter** les entités (NER + validateurs) sur le flux unifié.
5. **Regrouper** par coréférence pour **pseudonymiser** (HMAC) — voir section 7 du blueprint.
6. **Mapper chaque span -> bboxes** (multi-rectangles par ligne, fusion intra-ligne, **jamais** inter-ligne sans contrôle).
7. **Persister** un fichier `regions.json` (page, type, group_id, rectangles, pseudonyme).
8. **Caviardage** :
   - Ouvrir le **PDF original** (pas une re-impression).
   - Pour chaque rectangle : ajouter une **annotation de rédaction**, optionnel : poser un **rectangle plein** (couleur produit) ou un **texte de remplacement** (le pseudonyme `pr_a3f8`) **à la même bbox**.
   - **Apply redactions** : suppression des glyphes du flux de contenu.
   - Recompacter le **xref**, recompresser les flux.
9. **Nettoyer**
   - **Métadonnées** : `Author`, `Title`, `Subject`, `Producer`, `CreationDate`, `ModDate`, custom XMP, `Catalog.Names`.
   - **Hyperliens** : neutraliser ou réécrire les `Annot/Link` qui contiennent une PII (URL, mail).
   - **Pièces jointes** dans le PDF (`EmbeddedFiles`) : retrait ou anonymisation récursive.
   - **JavaScript** (`AcroForm/JS`, `OpenAction`) : retrait par défaut.
   - **Couche OCR** issue d’un Acrobat antérieur (`text on top of image`) : appliquer rédaction aussi sur cette couche.
10. **Vérifier** : voir contrôles ci-dessous.

#### Contrôles « PDF identique » (tests automatiques)

- **SSIM** par page > **0,98** sauf zones rédigées.
- **Compteur de glyphes** : sur les pages **sans** entité, écart **0** vs original ; sur les pages avec entités, écart = nombre de glyphes des spans.
- **Hash de pixels hors zones** : identique pixel à pixel (région masquée exclue).
- **Tableau sanity** : `pdftotext` du résultat **ne contient plus** les chaînes d’origine échantillonnées.
- **Métadonnées** : `exiftool` doit retourner un set vide / nettoyé.
- **Ouverture par Acrobat / Foxit / Apple Preview** : pas d’erreurs de structure (XRef OK, fonts embarquées OK).
- **Taille fichier** : ordre de grandeur cohérent ; alarme si > 2× (re-render parasite ?) ou si flux d’images cassés.

### 8.3 Cas spéciaux à ne pas rater

| Cas | Geste précis |
|------|--------------|
| **PDF scanné** (image pure) | OCR `PaddleOCR` -> mots + polygones ; rédaction = rectangles depuis polygones, **sur la couche image**. Ne **jamais** re-render en MD. |
| **PDF mixte** (image + couche texte) | Rédiger **les deux** couches : couche texte (glyphes) **et** couche image (rectangle peint pour cacher l’aspect visuel). |
| **Tableaux** | Multi-rectangles par cellule ; éviter de fusionner entre cellules. |
| **Entêtes / pieds de page répétés** | Mêmes occurrences sur N pages : appliquer rédaction sur **chaque** page. |
| **Police non embarquée** | Ne **pas** re-render (sinon perte). On ne fait que masquer / supprimer glyphes -> pas de re-typesetting. |
| **Champs de formulaire AcroForm** | Anonymiser la **valeur** (`/V`) **et** l’apparence (`/AP`) ; sinon le `/V` reste exploitable. |
| **Signatures numériques** | Toute rédaction **invalide** la signature -> avertir l’utilisateur ; option : **page additionnelle** indiquant l’invalidation. |
| **PDF chiffré (mot de passe)** | Refuser ou demander mot de passe ; ne **pas** tenter de contourner. |
| **Liens cliquables** | `Annot/Link` mis à jour ou supprimés si l’URI contient PII. |
| **Pages tournées** | Lire la **rotation** (`/Rotate`) et **rotater** les bbox avant rédaction. |
| **Plusieurs colonnes** | Le flux unifié doit respecter l’ordre **logique** (lecture humaine), sinon la NER se trompe sur les frontières d’entités. PDFBox `PDFTextStripper` + `setSortByPosition(true)` ; PyMuPDF `get_text("dict")` puis tri par blocs. |
| **Petites bbox imprécises** | Fusionner les mots d’une **même ligne** par seuil de gap horizontal ; padding 1–2 px. |

### 8.4 Pourquoi pas re-render depuis Markdown ?

- Perte de **polices propriétaires**, **logos vectoriels**, **tableaux complexes**, **images**, **signatures visuelles**, **mises en page** spécifiques (colonnes, encarts, marges).
- Perte de **métadonnées de facture** structurées (Factur-X / ZUGFeRD intégré dans certains PDF) — **à conserver intact** sauf instruction contraire.
- Risque pour la **valeur juridique** du document (dans certaines chaînes contractuelles, l’apparence est essentielle).

### 8.5 Comment **dépasser** Marvin sur ce point

1. **Pseudonymisation in place** : remplacer le mot rédigé par son **pseudonyme** (`pr_a3f8`) dans la **même bbox** avec **même police de substitution** (ex. `Helvetica`/`Arial`) ; rester lisible humainement, pas un simple bloc noir. Marvin propose les deux modes ; Agilotext peut **proposer plus** : choix par **type** (rectangle plein pour `IBAN`, pseudonyme pour `PR`, etc.).
2. **Conservation Factur-X / XML** : si la facture contient un XML embarqué normalisé (CII / UBL), proposer **deux variantes** : (a) anonymiser **aussi** le XML (cohérence) et (b) sortie « Factur-X anonymisé » ; cela **n’existe pas chez tous** les concurrents.
3. **Diff visuel** dans le rapport : générer une **planche** « avant / après » par page (small thumbnails), prouver à l’utilisateur que **rien d’autre** n’a bougé.
4. **Garantie « zéro fuite »** : test post-render qui rejette la sortie si une chaîne d’une **liste d’échantillons sensibles** est retrouvée par `pdftotext` ou `pdfplumber`.
5. **Préservation des **tagged PDF** (PDF/UA)** : conserver l’accessibilité (lecteurs d’écran) en mettant à jour la **structure** Marked Content au lieu de la **détruire**.
6. **Mode signature aware** : insertion d’une **page de garantie** détaillant ce qui a été masqué, signée par un certificat Agilotext (preuve de chaîne) — argument B2B fort.
7. **Audit log** : pour chaque rédaction, hash de la bbox + type ; permet à un client banque/avocat de **prouver** que la rédaction a été appliquée à tel endroit.

### 8.6 Recette équivalente côté **Office** (DOCX / XLSX / PPTX)

Mêmes principes, outils différents :

- **DOCX** : Apache POI (`XWPFRun`) -> remplacer **dans le run** en préservant `RPr` (style). Ne **jamais** reconstruire le `document.xml` à plat. Pour `track changes`, accepter d’abord puis remplacer, ou **rejeter** le document avec message.
- **XLSX** : POI `XSSFCell` ; pour les **formules** dépendantes, recalculer ou figer la **valeur cachée**.
- **PPTX** : POI `XSLFTextRun`. Penser aux **commentaires** et **notes**.
- Pour tous : **purger** `core.xml`, `app.xml`, `customXml`, `revisions`, **macros** (`vbaProject.bin`), **hyperlinks PII**.

### 8.7 Implémentation concrète recommandée pour Agilotext (au-dessus d’Anon2)

1. **Côté Java** :
   - Conserver la classe **`PdfNativeVisualRedactor`** (déjà existante) comme cœur.
   - Étendre : entrée = **liste de rectangles** par page (issue de `regions.json`).
   - Ajouter : **mode pseudonyme dans bbox** (police + taille auto-fit).
   - Ajouter : **purge AcroForm/JS/EmbeddedFiles** dans le même passage.
2. **Côté Python (Anon2)** :
   - Ajouter étape **`extract_with_positions`** (PyMuPDF) en plus du texte plat.
   - Émettre un **fichier unique** `regions.json` au schéma `markdownRegions` :

   ```json
   {
     "version": 1,
     "pages": [
       {
         "page": 1,
         "rotation": 0,
         "size": [595, 842],
         "occurrences": [
           {
             "type": "PR",
             "group_id": "g_017",
             "pseudonym": "pr_a3f8",
             "rectangles": [[120, 740, 230, 752]]
           }
         ]
       }
     ]
   }
   ```

3. **Contrat fichier inter-services** :
   - Entrée : `<doc>.pdf`
   - Sorties : `<doc>_anon.pdf`, `<doc>_anon.report.json` (rapport job), `<doc>_anon.regions.json` (audit), `<doc>_anon.diff.pdf` (option, A/B visuel).
4. **Tests d’acceptance “facture”** : jeu de **20 factures** (Factur-X, scanned, multi-pages, multi-colonnes, tableaux).
   - Métriques : SSIM moyen, F1 par entité, **0** chaîne PII résiduelle, taille +/- 10%.

### 8.8 Garde-fous (ce qu’il **ne faut pas** faire)

- Ne **pas** convertir PDF -> Markdown -> PDF en sortie : casse la fidélité.
- Ne **pas** recouvrir avec un rectangle sans **`apply_redactions()`** (les glyphes restent dans le flux et sont récupérables).
- Ne **pas** oublier la **rotation** des pages avant calcul des bbox.
- Ne **pas** stocker le **mapping pseudonyme -> identité** côté navigateur (`localStorage`) : c’est exactement la faille `pseudonymization-map` côté audit ; reste **côté serveur** chiffré (HMAC + KMS).
- Ne **pas** générer une page « Factur-X » si le XML embarqué a été modifié sans avoir mis à jour son hash CII/UBL — sinon la facture devient invalide.

---

## 9. Synthèse en trois phrases

1. **Marvin-type** = **BaaS + job unique + markdown + NER + JSON de régions + workers + temps réel + Stripe**.  
2. **Anon2** = **moteur de détection moderne (Presidio/GLiNER/validations) + intégration Java / fichiers** ; le **cœur scientifique** est comparable, le **câblage SaaS** (API job, MD canonical, SSE, mêmes champs) et le **rendu PDF identique** (rédaction *in place*, pas re-render) sont **à industrialiser** pour coller au paradigme.  
3. Le **chemin** le plus sûr n’est **pas** de “copier” PocketBase : c’est d’**implémenter le même *contrat fonctionnel*** (job, storage, schéma regions, worker, **rédaction spatiale in place**) **au-dessus** d’Anon2 et du monolithe Java existant, avec la roadmap ci-dessus et la recette section 8.

---

## 10. Liens utiles

- Blueprint défensif (détaillé, ne pas confondre avec ce court récap) : [MARVIN_CLONE_BLUEPRINT_2026.md](../marvin_intel/MARVIN_CLONE_BLUEPRINT_2026.md)  
- Architecture backend Marvin décodée : [MARVIN_BACKEND_DECODED.md](../marvin_intel/MARVIN_BACKEND_DECODED.md)  
- Détails techniques et historique Anon2 : [anon2_for_cursor.md](anon2_for_cursor.md)

---

*Dernière mise à jour : avril 2026.*
