---
title: "Brief interne - Ecart Anon2 / Marvin (post-audit HAR 2026)"
date: "Avril 2026"
author: "Equipe technique Agilotext"
---

# A l'attention de Nicolas

Ce document est **strictement interne** (non destine a Marvin). Il resume ce que l'audit passif (HAR + JS public) apporte a notre feuille de route Anon2 / Agiloshield, apres l'audit critique des sorties `IN/OUT` (rapport `RAPPORT_NICOLAS_ANON2_AVRIL_2026`).

## 1. Constat principal

Marvin n'est pas "magique" : ils ont un **BaaS** (PocketBase) + un **produit** qui trace tout dans une collection riche (`app_calls`) + un **NER** a **18 entites** sur du **texte extrait** (fichiers markdown + JSON de regions) plutot que seulement du dessin de rectangles.

Notre echec d'avril 2026 (fuites PII, layout) vient de l'**ecart d'execution** (recognizers, tests, parcours PDF) plus que du manque d'une idee de pipeline. L'ecart "concurrence" est aujourd'hui : **maturite produit** + **ontologie** + **UX d'assertion** + (du cote d'eux) **exposition reseau** a durcir.

## 2. Cinq enseignements actionnables

1. **Cible ontologie** : viser au minimum les memes 18 cles (ou les regrouper) avec priorite FRNIR, CID, CP, REF, FILE pour les use cases M&A / juridique.
2. **Pipeline** : s'assurer que le fil texte (markdown interne) est le **maitre** de la verite PII, puis reprojection sur le PDF (deja l'intention, pas toujours le resultat des OUT).
3. **UX** : prevoir a moyen terme un ecran "liste d'entites / validation" (meme leger) pour reprendre le niveau de confiance du marche.
4. **Securite** : notre filet de securite peut etre notre **discours** (pas de BaaS multi-tenant imposé, CORS stricite, hebergement FR) a condition de tenir l'implémentation.
5. **Metriques** : pour chaque type (FRNIR, email, etc.), taux de detection sur corpus fige - comme critere de release bloquant.

## 3. Lien avec la note 9/20

Cette fiche ne change pas la **note 9/20** sur le produit Anon2 telle qu'evaluée sur les PDFs : l'ecart **Marvin** explique le **marché**, pas l'etat de notre binaire. La note ne remontera qu'avec **re-tests** sur `OUT/` et **gates** (blocage release si fuite d'un NIR, etc.).

## 4. References

- [../marvin_intel/ECART_MARVIN_DIAGNOSTIC.md](../marvin_intel/ECART_MARVIN_DIAGNOSTIC.md) (matrice d'ecart detaillee)
- [../marvin_intel/MARVIN_BACKEND_DECODED.md](../marvin_intel/MARVIN_BACKEND_DECODED.md) (comment ils sont construits, cote observable)
- [RAPPORT_NICOLAS_ANON2_AVRIL_2026.md](RAPPORT_NICOLAS_ANON2_AVRIL_2026.md) (evaluation critique reelle des PDFs)

---

*Document interne Agilotext - ne pas diffuser.*
