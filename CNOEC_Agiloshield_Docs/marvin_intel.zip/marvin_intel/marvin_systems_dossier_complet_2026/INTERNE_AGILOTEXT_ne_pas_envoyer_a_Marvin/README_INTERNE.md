# Dossier interne Agilotext — ne pas transmettre à Marvin

Ce sous-dossier contient le **positionnement produit** et la **comparaison avec Anon2** : utile en interne, non demandé par un livrable client « audit Marvin » seul.

Fichiers :

- `ECART_MARVIN_DIAGNOSTIC.md` — leviers Anon2 / produit
- `PLAN_RECAP_BACKEND_MARVIN_VS_ANON2.md` — backend type Marvin vs Anon2, rendu PDF
- `ECART_MARVIN_DIAGNOSTIC.md` — thèse majeure (pipeline sémantique + regions), pivot Anon2
- `RAPPORT_NICOLAS_ECART_MARVIN_2026` — brief interne (md + pdf)

Pour l’archive **client Marvin**, utiliser le script `CREER_ZIP_POUR_MARVIN.sh` à la racine du dossier parent, qui **exclut** ce répertoire.

---

*CNOEC / Agiloshield — avril 2026*
