# Reconnaissance passive — preuve de stack (sans faille d’exploitation)

**Date** : 2026-04-27  
**Méthode** : requêtes **GET** publiques sur des URL déjà documentées (équivalent `curl` passif). **Aucune** tentative d’intrusion, d’IDOR, d’injection ou de brute force.

> **Message pour Marvin** : il n’y a pas besoin d’une « faille » pour deviner le backend. **PocketBase** et **Next.js** se **déclarent** eux-mêmes via des réponses HTTP et des chemins publics (`/_next/`, `/_/`, `/api/health`). C’est une **fuite d’information par conception** (fingerprinting), pas une CVE. Le durcissement passe par l’**acceptation** de cette visibilité (documentée, PDT) ou par un **reverse proxy** qui masque certains en-têtes (effet limité pour Next/PB tant que le client parle directement à l’API).

---

## 1. API `https://api.marvin-systems.com` — **PocketBase** (preuve forte)

### `GET /api/health` (200)

**Corps (extrait, 2026-04-27)** :

```json
{"message":"API is healthy.","code":200,"data":{}}
```

Ce JSON est le **message de santé documenté** pour PocketBase (même forme `message` / `code` / `data`).

**En-têtes observés** : `content-type: application/json`, `x-content-type-options: nosniff`, `x-frame-options: SAMEORIGIN`, HTTP/2, `alt-svc` HTTP/3, pas d’en-tête `Server` exposant Nginx/Apache (souvent masqué en amont).

### `GET /api/collections` (sans authentification)

**Corps (401, typique PocketBase)** :

```json
{"data":{},"message":"The request requires valid record authorization token.","status":401}
```

Même **formulation** que la documentation PocketBase pour l’accès non authentifié aux collections (selon règles par défaut).

### `GET /_/` (interface d’administration)

- **200** `text/html; charset=utf-8`
- **CSP** incluant `script-src 'self' 'sha256-...` — pattern habituel de l’**UI admin PocketBase** servie en statique.
- Cela ne donne **pas** le mot de passe admin, mais **confirme** la présence du panneau PocketBase sur ce host (à protéger par IP / VPN, 2FA, etc.).

**Conclusion** : le backend public `api.marvin-systems.com` se comporte comme un **PocketBase** standard. C’est cohérent avec tout le HAR et les findings déjà produits.

---

## 2. Site `https://marvin-systems.com` — **Next.js** (preuve)

### En-têtes (extrait, 2026-04-27)

- `x-powered-by: **Next.js**`
- `vary: rsc, next-router-state-tree, next-router-prefetch, next-router-segment-prefetch, ...` — indique **App Router** / **RSC**
- `set-cookie: NEXT_LOCALE=fr`
- Liens `/_next/static/...` dans `link` (preload)
- Fichiers HAR : présence de `turbopack-....js` dans les chunks — cohérent avec **Turbopack** côté build Next.

**Conclusion** : le front public est un **Next.js** moderne (App Router / RSC), en ligne avec l’audit des bundles.

---

## 3. Hôte `https://pb.marvin-systems.com` (second `PB_URL` dans les bundles)

**Observation au 2026-04-27** :

- `GET /api/health` : corps texte **`no available server`** avec **HTTP 503**.

Interprétation possible (sans accès interne) :

- Instance **coupée** ou **derrière** un équilibreur sans cible saine ; ou **décomission** partielle tandis que le nom DNS persiste.
- **Risque** : double DNS (déjà noté F2) + état **dégradé** sur un des deux hôtes — sujet **exploitation / sécurité opérationnelle** (confusion, certificats, chemins d’attaque de configuration).

**Recommandation** : 301 propre, retrait DNS, ou réparation explicite ; documenter un seul `PB_URL` côté client.

---

## 4. Que **ne** montre **pas** cette reconnaissance

- **Version exacte** de PocketBase (souvent absente des réponses publiques récentes).
- **Contenu** du moteur interne (BRAIN) : modèles ML, code Go des hooks, secrets — **non** exposés par ces appels.
- **Schéma** des collections : nécessite auth ou fuite (déjà partiellement visible dans le HAR authentifié).

---

## 5. Synthèse « stack » pour alerter Marvin (sans « faille »)

| Couche | Preuve (2026-04-27) |
|--------|---------------------|
| Front | Next.js (header + chemins `/_next/` + RSC) |
| API BaaS | PocketBase (health + 401 + `/_/`) |
| Legacy host `pb.*` | 503 + message « no available server » — à clarifier côté infra |
| ML / « Brain » | **Non** prouvé par requêtes passives (service interne) |

---

## 6. Périmètre éthique

Les commandes ci-dessus équivalent à ce que n’importe quel navigateur ou outil d’**inventaire** ferait. Pour aller plus loin (énumération de comptes, test IDOR, injection), il faut un **mandat écrit** et un périmètre **test d’intrusion** — hors scope de ce document.

---

*Document à joindre au dossier `marvin_systems_dossier_complet_2026` pour transparence méthodologique.*
