# Kit Marvin / prestation d'audit (avril 2026)

## Role de ce dossier

Ce répertoire regroupe le **travail d'audit passif** sur le concurrent Marvin Systems, dans le cadre d'une **prestation pour le client Marvin** (durcissement) et un **brief interne** Agilotext (positionnement produit).

### Dossier unique « tout-en-un » + zip client

Tout est regroupé pour envoi détaillé à Marvin dans :

**[marvin_systems_dossier_complet_2026/](marvin_systems_dossier_complet_2026/)**

- `A_HAR_fichier_source/` : copie du fichier `marvin-systems.com.har` + note de confidentialité  
- `B_preuves_brutes_HAR/` : `RAW_EVIDENCE.md`  
- `C_architecture_backend/` : `MARVIN_BACKEND_DECODED.md`  
- `D_audit_securite_findings_rapports/` : findings + rapports pentest (md + pdf)  
- `E_blueprint_defensif_reproductibilite/` : blueprint + pdf  
- `F_synthese_tables_clefs/` : `SYNTHESE_GLOBALE_cles_fuites_indicateurs.md`  
- `INTERNE_AGILOTEXT_ne_pas_envoyer_a_Marvin/` : **exclu** du zip Marvin (diagnostic interne, recap Anon2, brief Nicolas)  

À la racine de ce dossier : `LISEZMOI.md`, `MANIFEST_FICHIERS.md`, `CREER_ZIP_POUR_MARVIN.sh`.  
Le script génère `marvin_systems_livrable_audit_YYYYMMDD.zip` dans **`marvin_intel/`** (répertoire parent), prêt à transmettre.

## Cloison stricte des livrables

| Fichier | Public cible | Contenu |
|---------|-------------|---------|
| [RAW_EVIDENCE.md](RAW_EVIDENCE.md) | Auditeur + client Marvin (annexe) | Preuves brutes (URLs, IDs, en-têtes, extraits) |
| [RAW_FINDINGS_2026-04-27.md](RAW_FINDINGS_2026-04-27.md) | Idem + Agilotext interne | Niveau de preuve (HAR), schéma champs, manips A/B/C, `curl` passifs, fin chasse .map |
| [MARVIN_ARCHITECTURE_DECODED.md](MARVIN_ARCHITECTURE_DECODED.md) | Idem + produit / tech | 6 découvertes, diagramme flux, **nuance MD + régions** (vs seulement « texte→texte ») |
| [MARVIN_BACKEND_DECODED.md](MARVIN_BACKEND_DECODED.md) | Idem + équipe ingénieurs | Architecture décodée, diagramme, champs `app_calls` (mis à jour) |
| [FINDINGS_PENTEST_MARVIN.md](FINDINGS_PENTEST_MARVIN.md) | Client Marvin | 11 findings classés, remédiations |
| [../security/reports/RAPPORT_PENTEST_MARVIN_2026_EXEC.md](../security/reports/RAPPORT_PENTEST_MARVIN_2026_EXEC.md) | Direction / RSSI Marvin | 1 page exécutif |
| [../security/reports/RAPPORT_PENTEST_MARVIN_2026_TECH.md](../security/reports/RAPPORT_PENTEST_MARVIN_2026_TECH.md) | Équipe technique Marvin | Rapport long + liens preuves |
| [ECART_MARVIN_DIAGNOSTIC.md](ECART_MARVIN_DIAGNOSTIC.md) | **Agilotext interne seulement** | Conséquence stratégique Anon2 |
| [../NEW_VERSION_AVRIL_2026/RAPPORT_NICOLAS_ECART_MARVIN_2026.md](../NEW_VERSION_AVRIL_2026/RAPPORT_NICOLAS_ECART_MARVIN_2026.md) | **Interne (Nicolas)** | Synthèse produit + références |
| [../NEW_VERSION_AVRIL_2026/PLAN_RECAP_BACKEND_MARVIN_VS_ANON2.md](../NEW_VERSION_AVRIL_2026/PLAN_RECAP_BACKEND_MARVIN_VS_ANON2.md) | **Agilotext interne** | Plan récap : backend « type Marvin » vs Anon2 (alignement) |
| [MARVIN_CLONE_BLUEPRINT_2026.md](MARVIN_CLONE_BLUEPRINT_2026.md) | **Client Marvin (alarmiste, défensif uniquement)** | Blueprint v3 : étape par étape de reproductibilité intégrale d’une stack “type” (Next.js, PocketBase, workers NER, Stripe, etc.) — **zéro mention Agilotext** |
| [../security/reports/RAPPORT_BLUEPRINT_CLONE_MARVIN_2026.pdf](../security/reports/RAPPORT_BLUEPRINT_CLONE_MARVIN_2026.pdf) | **Idem (PDF dérivé du .md ci-dessus)** | Même contenu, export imprimable |

**Ne jamais** envoyer `ECART_MARVIN_DIAGNOSTIC.md` ni le rapport Nicolas au client Marvin.

## Fichiers PDF générés (meme emplacement que les .md)

- `security/reports/RAPPORT_PENTEST_MARVIN_2026_EXEC.pdf`
- `security/reports/RAPPORT_PENTEST_MARVIN_2026_TECH.pdf`
- `security/reports/RAPPORT_BLUEPRINT_CLONE_MARVIN_2026.pdf`
- `NEW_VERSION_AVRIL_2026/RAPPORT_NICOLAS_ECART_MARVIN_2026.pdf`

Génération : `pandoc` + `xelatex` (polices systeme Helvetica / Courier, `--syntax-highlighting=none`).

### Livrable Marvin (Blueprint Clone v3 — reproduction intégrale à l’identique, ton alarmiste)

- **`RAPPORT_BLUEPRINT_CLONE_MARVIN_2026.pdf`** : démonstration pas à pas de la reproductibilité d’une stack de ce type (provisioning, Next.js, PocketBase, workers NER, fine-tuning, CI/CD, GTM, défense SIEM, RGPD, anti-réplication des failles F1–F11).  
- **Cloison stricte** : aucun mot sur Agilotext, aucun contenu des livrables internes (Anon2, brefs Nicolas) ; cible = **avertir Marvin** et proposer un plan de durcissement, pas d’en fournir un mode d’emploi d’attaque.  
- Source Markdown : [MARVIN_CLONE_BLUEPRINT_2026.md](MARVIN_CLONE_BLUEPRINT_2026.md).

## Commandes `curl` passives (optionnel)

**Non exécutées** dans la rédaction initiale faute d'autorisation formelle. Si le client signe l'autorisation :

```bash
curl -sI https://api.marvin-systems.com/api/health
curl -sI https://api.marvin-systems.com/_/
curl -s  https://api.marvin-systems.com/api/health
curl -sI https://pb.marvin-systems.com/api/health
```

## Sources d'entree (hors repo)

- Fichier HAR : `marvin-systems.com.har` (sauvegarde locale de l'auditeur)
- Dossier HTML offline : `Anonymisation de documents - ... _ Marvin Systems.html` + `*_files/`

## Mise a jour

Regénérer les rapports apres chaque grosse release du concurrent (re-capture HAR + bundles).

---

*Index maintenu par l'équipe Agilotext (documentation CNOEC / Agiloshield).*
