# Ecart strategique Agilotext (interne) - lecture de la prestation Marvin

**Document strictement interne** - ne pas joindre au livrable client Marvin.  
Cible lecteurs : equipe produit, Nicolas (Anon2), direction technique.

## 1. Ce que l'audit Marvin change pour notre feuille de route (these majeure avril 2026)

L'analyse HAR + reponses JSON confirment un **produit bati sur un texte intermediaire** (markdown / flux normalise) + **NER a 18 types** + **fichiers et champs de regions** (`markdownRegions`, `redactionRegions`) + **editeur** (vue `edit_view=markdown` exposee) + suivi d'etat (PocketBase, SSE).  

**L'ecart n°1 n'est donc pas** « ils ont un meilleur GLiNER en isolation » : c'est **l'assemblage** — *pipeline sémantique (MD) + ontologie riche + regions persistees + produit (job, credits, temps reel)* — **versus** un pipeline Anon2 encore **trop centre** caviardage spatial **sans** la meme couche sémantique / contrat de regions unifie. Voir [MARVIN_ARCHITECTURE_DECODED.md](MARVIN_ARCHITECTURE_DECODED.md) section 2 (nuance : **NLP sur MD n'exclut pas** l'application **spatiale** sur PDF ; il faut **les deux** pour une facture identique).

**Lecture obligatoire interne** : [RAW_FINDINGS_2026-04-27.md](RAW_FINDINGS_2026-04-27.md) (niveau de preuve, ce que le HAR prouve vs ce qu'il ne prouve pas) ; [../NEW_VERSION_AVRIL_2026/PLAN_RECAP_BACKEND_MARVIN_VS_ANON2.md](../NEW_VERSION_AVRIL_2026/PLAN_RECAP_BACKEND_MARVIN_VS_ANON2.md) section 8 (recette PDF a l'identique).

| Dimension | Marvin (observé) | Anon2 (avril 2026) | Ecart |
|-----------|-----------------|--------------------|--------|
| Pipeline | doc -> md -> NER sur md -> md anonyme + regions JSON | redaction PDF spatiale + NLP sur pipeline decide | Ils separent **layout** et **sens** ; notre dette = fuites PII quand NER ne couvre pas un format |
| Ontologie | 18 types, FRNIR/CID/CP/REF/FILE/... | ~7 types Presidio "par defaut" en intention | A combler cote config + recognizers |
| Produit | SPA Next, temps reel, credits, whitelists | Webflow + batch Java/CLI | Ecart **UX** et **verifiabilite** cote client |
| Infra securite | CORS lache, token navigateur, double API : **ne pas copier** | Notre stack differente : capitaliser sur **moins d'exposition** (pas de CORS * sur BaaS, pas de BaaS public pour les donnees cliniques) | Opportunite de message commercial |

## 2. Cinq leviers concrets (priorisés)

1. **Aligner l'ontologie** : cible minimale 15-18 types alignes ou superieurs a Marvin pour les cabinets FR (FRNIR, SIRET/TVA, CP separe, REF, FILE).
2. **Pipeline "markdown de travail"** + **schema `regions` unifie** (aligne HAR) : NER sur texte/MD, puis **mappage** vers PDF/Office via spans ou JSON de regions — **pivot strategique** documente (ne pas supprimer PDFBox, le **nourrir** apres NER/regex/GLiNER alignes 18 entites).
3. **Portail client** (phase 2) : un ecran d'edition et de verification des entites, comme levier de confiance, sans exposer d'ID en URL non-opaque.
4. **Sécurité** : notre offre peut afficher **CORS stricte**, **pas de stockage de jeton fichier en clair** dans le Webflow, **pas de BaaS multi-tenant** si le client l'exige (instance dediee).
5. **Mesure** : jeux de tests PDF+DOCX+EML avec les 18 types ; scores F1 par type, pas seulement global.

## 3. Lien avec la note 9/20 (Rapport Anon2)

La prestation Marvin **ne rehausse pas** la note actuelle d'Anon2 : elle explique *pourquoi* le concurrent semble "plus haut" (produit mûr, ontologie, UX). La note interne ne bouge qu'avec **re-tests sur OUT/** et garde-fous (gates) sur NIR, emails, telephones (cf. RAPPORT_NICOLAS_ANON2).

## 4. Pistes de differentiation honnetes

- **Hébergement** : Normandie, instance dédiée, tracabilite d'hebergement.
- **Pas de "petit" product analytics sur le document** : moins d'exposition de contenu a des tiers.
- **Transparence** : description du pipeline (extract -> detect -> apply) et rapports d'execution JSON pour l'assurance qualite (deja le sens du rapport `anon2`).

---

*Rédige pour capitaliser l'intel de concurrence de maniere ethique et legale. Ne pas reutiliser d'artefacts internes non publics de Marvin ; uniquement HAR/JS publics et observations.*
