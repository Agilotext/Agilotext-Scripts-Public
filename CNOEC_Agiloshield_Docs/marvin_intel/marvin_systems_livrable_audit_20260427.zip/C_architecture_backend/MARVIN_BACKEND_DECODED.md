# Architecture backend et produit Marvin Systems (decodee)

Sources : [RAW_EVIDENCE.md](RAW_EVIDENCE.md), chunks Next.js/Turbopack, HAR `marvin-systems.com.har`.

## 1. Vue d'ensemble

| Couche | Technologie inferiee | Commentaire |
|--------|---------------------|-------------|
| Front | Next.js (App Router, `?_rsc=`), Turbopack, React, Radix UI, react-intl | SPA riche : editeur d'anonymisation, vues markdown, session storage |
| API / donnees | **PocketBase** (Go, binaire unique) | Collections REST, fichiers stockes, SSE `/api/realtime` |
| Hebergement | Scaleway (IP `51.158.124.96`, Paris) | Pas de CDN/WAF evident sur l'API |
| Paiement | **Stripe** via collection `StripeSessions` | Customer Portal / sessions (pattern classique PocketBase + Stripe) |
| Analytics | **PostHog** (proxy `marvin-systems.com/ph/`) + **Google Ads** (tag `gtag`, conversion) | Enregistreur de session `posthog-recorder.js` charge sur l'appli |

## 2. Domaines

- **Site** : `https://marvin-systems.com`
- **API PocketBase (actif, HAR)** : `https://api.marvin-systems.com`
- **API legacy (encore referencee dans un chunk)** : `https://pb.marvin-systems.com` -> a traiter (redirection / decommission)

## 3. Donnees metier : collection `app_calls`

Tous les jobs d'anonymisation passent par une seule collection (`collectionId` = `pbc_614331130`).

**Pipeline deduit des noms de champs** (ordre logique) :

1. **Upload** : `originalInput` = fichier (PDF, etc.) uploade ; `processor` = `anonymize` ; `selectedEntities` = 18 types choisis cote UI.
2. **Extractor** : compteurs `extractor*Chunks` / `extractorDuration` -> production de texte (references `markdownInput` vers fichier `.md` en storage).
3. **Tokenizer / sanitizer** (noms de champs) : `tokenizedInput`, `sanitizedInput` (stocke cote enregistrement quand le workflow le remplit).
4. **Analyzer (NER)** : `analyzer*Chunks` / `analyzerDuration` ; resultat `occurrences` (regroupe par type) et `markdownRegions` (JSON spatial/structure).
5. **Sortie** : `markdownOutput` (fichier), credits debites (`credits`).

**Nuance (preuve HAR + noms de champs)** : la presence de `markdownRegions` (fichier JSON), `redactionRegions` et `customRedactionRegions` indique que le produit ne se limite pas au **texte seul** : une **couche de regions** sert a **structurer** et a **appliquer** l'anonymisation sur le document final (y compris PDF « a l'identique » en reliant entites et emplacements). Le NER **s'appuie** sur la vue texte / markdown ; la **sortie** peut **reposer** sur ces regions pour le rendu (cf. [MARVIN_ARCHITECTURE_DECODED.md](MARVIN_ARCHITECTURE_DECODED.md) section 2).

**Fichiers references** (exemples de noms) : `markdown_input_*.md`, `markdown_output_*.md`, `markdown_regions_*.json` - accessibles via `GET /api/files/pbc_614331130/{recordId}/...?token=...`.

**Temps reel** : le client s'abonne a `app_calls/*` et `app_calls/{id}` sur `/api/realtime` (SSE) pour le suivi d'avancement (chunks, erreurs).

## 4. Ontologie NER (18 types)

Cles envoyees dans `selectedEntities` (constantes du client) :

`PR, MAIL, PHON, CIE, ORG, ACT, CID, ADR, LOC, URL, IP, IBAN, CARD, REF, FILE, FRNIR, DT, CP`

Interpretation fonctionnelle :

- **FRNIR** : NIR (INSEE) france, reconnaissance dediee.
- **CID** : identifiants contractuels / sociaux (SIRET, TVA, etc. selon contexte).
- **CP** : code postal, separe d'**ADR** (adresse) et **LOC** (localite).
- **Validation** (deduite du positionnement produit) : `IBAN` (Mod-97), `CARD` (Luhn), NIR (cle) - a confirmer par tests bord.

## 5. Securite transport et headers

- **zstd** + **alt-svc HTTP/3** : stack moderne.
- **CORS** sur API echantillonne : `Access-Control-Allow-Origin: *` (a restreindre en prod).
- **HSTS** : present sur des reponses `marvin-systems.com` (d'autres requetes HAR) ; l'API JSON echantillonnee pour `app_calls` n'incluait **pas** `Strict-Transport-Security` (aligner les deux origines sur une politique stricte).
- **CSP** : non observe sur l'API ; a definir cote Next + reverse proxy PocketBase.
- `X-Frame-Options: SAMEORIGIN`, `X-Content-Type-Options: nosniff` (API).

## 6. Moteur interne "BRAIN"

Le bundle client reference `BRAIN_URL`, `BRAIN_AUTH_KEY`, `BRAIN_AUTH_SECRET` (via `process.env` / `next` config). Cela designe vraisemblablement un service interne d'analyse (NER, post-traitement) appele cote **serveur** (hooks PocketBase ou worker). Aucune URL "brain" n'a ete trouvee inlinée dans les chunks JS analyses ; l'absence de valeur dans le code statique n'exclut pas une mauvaise config `NEXT_PUBLIC_*` a verifier en CI.

## 7. Diagramme de flux

```mermaid
flowchart LR
  browser[Navigateur] --> nextjs[Next.js_Turbopack]
  nextjs --> pbapi[api.marvin_systems.com_PocketBase]
  nextjs --> ph[PostHog_proxy_ph]
  nextjs --> gads[Google_Ads]
  pbapi --> files[Storage_fichiers_md_json_pdf]
  pbapi --> sse[SSE_api_realtime]
  pbapi -.-> brain[Service_BRAIN_NER_serveur]
  brain --> pbapi
  pbapi --> stripe[Stripe_via_StripeSessions]
  sse --> browser
```

(Identifiants mermaid sans espaces pour compatibilite rendu.)

## 8. Ce que cette architecture revele a un concurrent

- Le **paradigme** "document -> markdown / texte normalise -> NER -> sorties (md + **regions** + champs de redaction)" : le **layout** n'est pas ignore (fichiers `*regions*` et champs `redaction*`), meme si le **moteur linguistique** travaille sur une representation textuelle.
- L'**exhaustivite** de l'ontologie (incl. FR, codes postaux, NIR, references).
- Le **BaaS** (PocketBase) comme pivot unique (auth, jobs, facturation, fichiers) : simplifie l'emulation cote R&D (meme API REST documentee) mais multiplie les risques si regles d'acces / CORS / stockage local sont laches.

## Voir aussi

- [MARVIN_ARCHITECTURE_DECODED.md](MARVIN_ARCHITECTURE_DECODED.md) : synthese des 6 decouvertes, diagramme, nuance MD vs spatial, pivot Anon2.
- [RAW_FINDINGS_2026-04-27.md](RAW_FINDINGS_2026-04-27.md) : niveau de preuve, manips A/B/C, curl passifs.
- [FINDINGS_PENTEST_MARVIN.md](FINDINGS_PENTEST_MARVIN.md) : risques et remédiations.
- [../security/reports/RAPPORT_PENTEST_MARVIN_2026_TECH.md](../security/reports/RAPPORT_PENTEST_MARVIN_2026_TECH.md) : rapport client (technique).
