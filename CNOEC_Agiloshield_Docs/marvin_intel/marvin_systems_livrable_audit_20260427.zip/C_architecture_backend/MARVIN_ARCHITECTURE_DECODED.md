# Architecture Marvin Systems — synthèse structurante (déc. 2026-04-27)

**Lectures connexes** : [MARVIN_BACKEND_DECODED.md](MARVIN_BACKEND_DECODED.md) (détail technique), [RAW_FINDINGS_2026-04-27.md](RAW_FINDINGS_2026-04-27.md) (niveau de preuve, schéma champs, manips).  
**Public** : équipe produit, audit client Marvin, ingénierie Agilotext.

---

## 1. Les six découvertes qui structurent l’analyse

1. **Backend = PocketBase** sur l’hôte `api.marvin-systems.com` (routes, fichiers, SSE) — **prouvé par HAR**.  
2. **Une collection métier** : `app_calls` — un enregistrement = un **job** d’anonymisation (aligné pratique BaaS minimaliste).  
3. **Pipeline nommé** : `extractor*` (conversion / préparation) puis `analyzer*` (NER) ; textes intermédiaires `tokenizedInput` / `sanitizedInput` — **prouvé par champs JSON**.  
4. **Artefacts Markdown + JSON** : `markdown_input_*.md`, `markdown_output_*.md`, `markdown_regions_*.json` — **prouvé** (URLs de fichiers dans le HAR).  
5. **Front** : Next.js (App Router / `?_rsc=`), Turbopack, proxy PostHog, Google Ads — **prouvé** (navigateur + HAR + bundles).  
6. **Surface attaquable côté confiance** : CORS `*`, HSTS / CSP inégaux, absence de WAF évident, jetons côté navigateur — **rapport d’audit** (findings) ; pas une invitation à l’exploitation.

---

## 2. Nuance essentielle : Markdown NER **et** spatial (ne pas simplifier en « eux = texte, nous = PDF »)

**Ce que le HAR prouve sans ambiguïté** : le produit s’appuie sur une **chaîne de texte** (markdown) pour le **travail sémantique** (détection, éditeur, vue `edit_view=markdown`).

**Ce que les champs prouvent aussi** : l’existence de **`markdownRegions`**, **`redactionRegions`**, **`customRedactionRegions`**. Un fichier nommé `markdown_regions_*.json` n’a de sens opérationnel que s’il porte des **métadonnées de localisation** (page, offset, boîte, etc.) — à minima pour **reprojeter** sur le document final ou sur la prévisualisation.

**Donc** :

- **Faux** : « Marvin ne fait *que* du texte → texte et jamais de coordonnées. »  
- **Vrai** : **NER et édition** sur une vue **texte/MD** normalisée ; **application** de l’anonymisation sur le **fichier cible** en s’appuyant sur des **régions** (JSON + champs de rédaction). Pour un **PDF** « à l’identique », la voie cohérente est : **détecter** sur le texte, **rédacter** en utilisant le **lien** texte → géométrie (d’où les régions) — aligné sur [PLAN_RECAP_BACKEND_MARVIN_VS_ANON2.md](../NEW_VERSION_AVRIL_2026/PLAN_RECAP_BACKEND_MARVIN_VS_ANON2.md) section 8.

**Conséquence pour Agilotext** : l’écart n’est pas *« PDFBox vs zéro PDF »* ; c’est *« pipeline sémantique (MD) + ontologie 18 + régions + produit (SSE, BaaS) »* **vs** *« caviardage spatial sans couche sémantique assez riche »*. Le `PdfNativeVisualRedactor` **reste pertinent** s’il est **nourri** par des **spans/régions** issus d’un moteur aligné sur la même ontologie.

---

## 3. Schéma de flux de données (logique, compatible HAR)

```mermaid
flowchart TB
  subgraph upload [Upload]
    U[Utilisateur] -->|multipart| POST[POST_app_calls_records]
  end
  subgraph pb [PocketBase]
    POST --> REC[Enregistrement_app_calls]
    REC --> F[Storage_fichiers]
  end
  subgraph worker [Traitement asynchrone inféré]
    F --> EX[extractor]
    EX --> MDIN[markdown_input.md]
    EX --> TI[tokenized_sanitized]
    TI --> AN[analyzer_NER]
    AN --> OCC[occurrences]
    AN --> REGF[markdown_regions.json]
    AN --> OUT[markdown_output.md]
    OUT --> RRED[redactionRegions_et_fin]
  end
  REC --> SSE[SSE_realtime]
  SSE --> U
  brain[Service_côté_serveur_BRAIN_?] -.->|inféré| EX
  brain -.-> AN
```

*Les pointillés* : aucune preuve d’URL « brain. » dans les bundles publics ; le traitement est **côté serveur** (hooks, worker, tâche planifiée).

---

## 4. Ontologie (18 clés) — alignement interne

Référence unique : [MARVIN_BACKEND_DECODED.md](MARVIN_BACKEND_DECODED.md) section 4. **ACT** = activité / rôle (pas le libellé anglais *JOB* dans le payload HAR documenté).

---

## 5. Prévenir Marvin : quoi transmettre sans « pousser » une attaque

Le livrable client peut inclure : **findings** (F1–F11), **HAR** (sous NDA), **ce document**, **synthèse des headers** — le tout pour **correction**, pas pour exploitation.

**Vérifications passives** : voir [RAW_FINDINGS_2026-04-27.md](RAW_FINDINGS_2026-04-27.md) section G (curl) et [FINDINGS_PENTEST_MARVIN.md](FINDINGS_PENTEST_MARVIN.md).

**À ne pas faire** : tests d’IDOR en masse, scans agressifs, contournement auth — **hors** périmètre d’un audit actif autorisé.

---

## 6. Pivot recommandé Anon2 (rappel)

1. **Canonique** : texte/MD de travail + mêmes **labels** (18) + validateurs **CID/FRNIR/CP** etc.  
2. **Sortie PDF** : conserver le **fichier d’origine** et appliquer **régions/spans** (déjà la direction du plan technique interne).  
3. **Produit** : traçabilité job + rapport (même si le BaaS n’est pas PocketBase).  
4. **Sécurité** : ne **pas** reproduire CORS `*`, localStorage de jetons sensibles, `edit=id` **sans** UUID + RLS (cf. findings).

---

## 7. Manips A / B / C (avant d’affirmer 100 % sur le moteur extracteur/NER)

| ID | Objectif | Action |
|----|----------|--------|
| **A** | Schéma exact de `markdown_regions_*.json` | DevTools → Network → fichier → copier le JSON (Preview) |
| **B** | Chaîne d’upload | Preserve log, POST multipart vers `app_calls/records` |
| **C** | Appels externe pendant 10–20 s de traitement | Filtre domaines (HF, OpenAI, Mistral, etc.) ; si **rien**, moteur interne probable |

Ces manips alimentent une **V2** de ce document, pas un blocage pour **prévenir** Marvin aujourd’hui (déjà 80 %+ sur l’ossature).

---

*Dernière mise à jour : 2026-04-27*
