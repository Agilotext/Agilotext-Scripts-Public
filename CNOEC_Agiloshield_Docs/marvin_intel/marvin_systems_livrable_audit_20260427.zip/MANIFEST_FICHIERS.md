# Manifest — inventaire des fichiers (marvin_systems_dossier_complet_2026)

Généré pour traçabilité. Les chemins sont relatifs à `marvin_systems_dossier_complet_2026/`.

| Chemin | Description |
|--------|-------------|
| `LISEZMOI.md` | Entrée du dossier, instructions zip Marvin |
| `MANIFEST_FICHIERS.md` | Ce fichier |
| `CREER_ZIP_POUR_MARVIN.sh` | Script de packaging pour Marvin |
| `A_HAR_fichier_source/marvin-systems.com.har` | Capture HTTP (session auditeur) |
| `A_HAR_fichier_source/NOTE_CONFIDENTIALITE_HAR.md` | Avertissement confidentialité |
| `B_preuves_brutes_HAR/RAW_EVIDENCE.md` | Extraction structurée des observables HAR/JS |
| `B_preuves_brutes_HAR/RAW_FINDINGS_2026-04-27.md` | Niveau de preuve, schéma champs, manips A/B/C, `curl` passifs, arrêt chasse .map |
| `C_architecture_backend/MARVIN_BACKEND_DECODED.md` | Stack, `app_calls`, NER, BRAIN (mis à jour nuance regions) |
| `C_architecture_backend/MARVIN_ARCHITECTURE_DECODED.md` | Synthèse 6 découvertes, diagramme, pivot vs Anon2 |
| `D_audit_securite_findings_rapports/FINDINGS_PENTEST_MARVIN.md` | 11 findings |
| `D_audit_securite_findings_rapports/RAPPORT_PENTEST_MARVIN_2026_EXEC.md` | Rapport exécutif (md) |
| `D_audit_securite_findings_rapports/RAPPORT_PENTEST_MARVIN_2026_EXEC.pdf` | Rapport exécutif (pdf) |
| `D_audit_securite_findings_rapports/RAPPORT_PENTEST_MARVIN_2026_TECH.md` | Rapport technique (md) |
| `D_audit_securite_findings_rapports/RAPPORT_PENTEST_MARVIN_2026_TECH.pdf` | Rapport technique (pdf) |
| `E_blueprint_defensif_reproductibilite/MARVIN_CLONE_BLUEPRINT_2026.md` | Blueprint défensif (md) |
| `E_blueprint_defensif_reproductibilite/RAPPORT_BLUEPRINT_CLONE_MARVIN_2026.pdf` | Blueprint (pdf) |
| `F_synthese_tables_clefs/SYNTHESE_GLOBALE_cles_fuites_indicateurs.md` | Tableau de synthèse |
| `INTERNE_AGILOTEXT_ne_pas_envoyer_a_Marvin/README_INTERNE.md` | Cloison interne |
| `INTERNE_AGILOTEXT_ne_pas_envoyer_a_Marvin/ECART_MARVIN_DIAGNOSTIC.md` | Diagnostic stratégique interne |
| `INTERNE_AGILOTEXT_ne_pas_envoyer_a_Marvin/PLAN_RECAP_BACKEND_MARVIN_VS_ANON2.md` | Recap Anon2 vs Marvin |
| `INTERNE_AGILOTEXT_ne_pas_envoyer_a_Marvin/RAPPORT_NICOLAS_ECART_MARVIN_2026.md` | Brief Nicolas (md) |
| `INTERNE_AGILOTEXT_ne_pas_envoyer_a_Marvin/RAPPORT_NICOLAS_ECART_MARVIN_2026.pdf` | Brief Nicolas (pdf) |

**Hors copie (référence seulement)** : sauvegarde HTML/JS `*_files/` citée dans `RAW_EVIDENCE` — à ajouter manuellement si fournie par l’auditeur.

---

*Mise à jour : avril 2026*
