---
title: "Blueprint Clone — Reproduction integrale a l'identique (v3, avril 2026)"
subtitle: "Etude technique defensive destinee a Marvin Systems"
author: "Redaction independante (prestation audit / durcissement)"
date: "2026-04-27"
lang: fr
---

# Avertissements (pages 1–2, a lire en premier)

Ce document est **strictement defensif et pedagogique** pour l’equipe Marvin Systems. Il decrit la **reproductibilite generale** d’une stack d’anonymisation de documents telle qu’elle pourrait etre reconstituee a partir de **briques open source 2025–2026** et d’**observations publiques** (site web, headers HTTP, patterns d’API documentes pour PocketBase, ecosysteme Next.js, etc.).

- **Aucun credential, cle, token, schema PocketBase de production, ni contenu de bundle client** n’est reproduit ici a l’etat de secret exploitable. Les noms d’hotes cites sont **descriptifs** d’architectures types et issus de travaux d’audit passif antecedents, sans re-livraison d’extraits sensibles.
- **Aucun produit "pret a cloner"** n’est fourni : uniquement des **spécifications**, des **tableaux de choix technologiques**, des **blocs de pseudo-code** et des **procedures d’hardening** pour aider Marvin a **reperer les vecteurs de copie** et a renforcer **barrieres techniques, juridiques et contractuelles**.

Les parties XVII (GTM) et 67–68 incluent un **avertissement legal explicite** : certaines conduites (prospection automatisée non consentie, atteinte a des mesures d’acces) sont **illicites** en Europe et ailleurs. La section 67 sert a **informer la defense** (clauses, formation, DPA) et non a fournir un manuel d’agression commerciale.

---

# Partie I — Synthese et cadre

## 1. Synthese executive (ton alarmiste, faits cadrés)

**Verdict** : l’ossature fonctionnelle d’un produit "upload multi-format -> markdown -> NER 18 entites -> pseudonymisation stable -> re-export PDF/Office/email/tableur" est **hautement reproductible** en combinant : Next.js, PocketBase, workers Python, modeles NER pre-entraines, stockage S3, Stripe, outils d’ingestion (Marker / PyMuPDF4LLM / Docling) et d’OCR (PaddleOCR). **Prototypage 7 jours, MVP serieux 14–21 jours, parite "vision produit" 60–90 jours** (UX, securite, support, DPA) selon l’ambition d’equipe.

- **Ressource typique (copie "lab")** : 1 senior backend + 1 ingenieur ML + 0,25 devops (temps partiel).  
- **Infra indicative** : 3,5–6 kEUR/mois (GPU L4/spot + instances CPU + stockage S3 + managed Postgres/Redis) avant optimisation.  
- **Qualite NER cible (macro-F1) sans corpus proprietaire** : 70–80 % en zero-shot + regex ; **+10–15 points** apres fine-tuning interne 300–500 documents labellises.  
- **Score de copiabilite fonctionnelle (abstrait, echelle 0–10)** : **8,5/10** — le difficile n’est plus le "cœur ML" (OSS abondant) mais la **fidelite layout + conformite + support client + zero-fuite** sur grands comptes.

L’innovation d’un editeur comme Marvin reside dans l’**assemblage, la fiabilite, la securite des flux et la prise de risque commerciale** — pas dans une brique "impossible a dupliquer" techniquement.

## 2. Cadre ethique, legal, RGPD

- **DPIA** obligatoire si traitement a grande echelle d’PII.  
- **Sous-traitance** (hebergeur, email, analytics, Stripe) : art. 28 RGPD, DPA, liste des sous-traitants.  
- **Sécurite** : art. 32 — chiffrement (TLS, at-rest), minimisation, journalisation sans PII en clair, duree de conservation.  
- **Cette etude n’inclut pas** de credentials, d’exploits, ni d’outils d’ingestion **contre** l’infrastructure d’un tiers sans mandat. Les lecteurs côté Marvin l’utilisent pour **prioriser les correctifs** listes (findings F1–F11, voir section 22).

## 3. Carte d’identite de la cible (observations d’audit passif, synthese)

| Couche | Technologie (inferée / documentée publiquement) | Role |
|--------|-----------------------------------------------|------|
| Front | Next.js (App Router, RSC, Turbopack) | App web, editeur, i18n |
| Donnees / API | PocketBase (Go, binaire) | Auth, stockage, jobs, temps reel |
| Hebergement | Cloud europeen (ex. Scaleway, region Paris) | API et fichiers |
| Paiement | Stripe | Abonnement / pre-paiement |
| Analytics | PostHog (souvent proxifie) + publicite | Mesure, campaigns |
| Transport | HTTP/2–3, compression moderne (ex. zstd) | Perfs, latence |

**Diagramme d’ensemble (Mermaid, simplifie)**

```mermaid
flowchart TB
  subgraph client [Client]
    Browser[Navigateur]
  end
  subgraph edge [Bordure]
    Next[Nextjs_App]
    PH[PostHog_proxy]
  end
  subgraph data [Donnees]
    PB[PocketBase_API]
    S3[Storage_S3_ou_fichiers_PB]
  end
  subgraph worker [Traitement]
    BRAIN[Service_BRAIN_NER_workers]
  end
  Browser --> Next
  Next --> PB
  Next --> PH
  PB --> S3
  PB --> BRAIN
  BRAIN --> PB
  PB --> Stripe[Stripe]
```

*Les noms de variables côté build client faisant référence a un "BRAIN" ont ete signales en audit (finding F1) : elles doivent disparaitre des bundles publics.*

---

# Partie II — Le "Brain" en profondeur

## 4. Architecture du service Brain (inference, files d’attente, GPU)

- **File d’attente** : Redis Streams (ou RabbitMQ) pour `job_id` avec etats `QUEUED, RUNNING, SUCCEEDED, FAILED, DEAD_LETTER`.  
- **Workers** :  
  - **Fast lane** : petits PDF/texte, latence cible p95 < 15 s.  
  - **Batch lane** : gros lots, back-pressure, autoscaling separe.  
- **GPU** : instances L4 (24 Go) ou H100 en spot pour fine-tune et charge pics ; **CPU AVX-512** pour ONNX / petite sequence.  
- **Orchestration** : worker Python (asyncio) + sidecar `prometheus` ; pas d’inference sur le process PocketBase (eviter blocage du binaire Go).

**Diagramme (Mermaid, interne workers)**

```mermaid
flowchart LR
  Q[Redis_Streams] --> W1[Worker_GPU_vLLM_ou_pytorch]
  Q --> W2[Worker_CPU_ONNX]
  W1 --> PB[(PocketBase_maj_champs)]
  W2 --> PB
  W1 --> M[MLflow_ou_registry]
```

## 5. Pipeline interne (ordre des etapes)

Ordre logique reproductible, aligne sur les champs `app_calls` de type inferes dans l’audit :

1. `extractor` : fichier -> `markdown` (+ metadonnées, extraits binaires si besoin).  
2. `tokenizer` : segmentation, offsets caracteres, phrases.  
3. `sanitizer` : heuristiques + regex a forte precision (IBAN, SIRET, email, etc.).  
4. `analyzer` (NER) : 18 types (voir annexe A5), fusion de modeles, scores de confiance, interval tree (chevauchements).  
5. `pseudonymizer` : regles de groupement + IDs stables + table des pseudonymes.  
6. `renderer` : application des remplacements + sorties PDF/Office/email/tableur.  
7. `markdownOutput` + `markdownRegions` (JSON spatial si coordonnees conservees) persistes.  

**Microservices vs monolithe** : monolithe Python + modules internes accélère le time-to-MVP ; decouper `extractor` (IO lourd) et `analyzer` (GPU) en services quand la charge l’impose.

## 6. Modele de donnees (generique, sans identifiants de production)

Collections types (a adapter en migrations PocketBase) :

- **`app_calls` (ou `jobs`)** : `id`, `user_id`, `tenant_id`, `status`, `selected_entities` (list), `credits` ou `usage_units`, compteurs `extractor*`, `analyzer*`, durees, references fichiers `markdown_input`, `markdown_output`, `markdown_regions` (fichier JSON), `error_code`.  
- **`files`** : cles, MIME, `sha256`, taille, prefixe d’acces signe.  
- **`pseudonyms`** : chiffre par `tenant` ; cle d’enveloppe (KMS ou derivee) ; jamais en `localStorage` (corrige F3).  
- **`stripe_sessions`** : ids Stripe, etat, mapping `user`.  
- **`audit_log`** (append-only) : acteur, action, cible, hash (sans PII en clair).  

Regles : `listRule` / `viewRule` / `updateRule` **basees sur l’authentification** (pas d’acces en lecture par ID devinable — corrige F4 type IDOR).

## 7. Pseudonymisation stable (principe, pseudo-code)

- **Groupe d’entite** : toutes les occurrences liées a une meme personne partagent un `groupKey` (coreference heuristique + ID de mention).  
- **Determinisme** : `token = HMAC-SHA256(MK, tenant | entityType | groupKey)[:8]` avec `MK` maitre en HSM / Vault.  
- **Reversibilite** : dictionnaire côté **serveur** chiffre, rotation de cle, DSR "effacement" = purge cles de groupe.  
- **Expiration** : purge automatique 30 j (souvent alignee RGPD / contrat).

**Pseudo-code (illustration)**

```python
def entity_token(entity_type, group_key, tenant_id, master_key) -> str:
    import hmac, hashlib
    msg = f"{tenant_id}|{entity_type}|{group_key}".encode("utf-8")
    digest = hmac.new(master_key, msg, hashlib.sha256).hexdigest()
    return f"{entity_type}_{digest[:8]}"
```

## 8. NER en production (metriques, ressources, observabilite)

| Metrique | Cible indicatif e-commerce B2B |
|----------|--------------------------------|
| p50 / p99 latence job | 5–30 s / 2–5 min (selon doc) |
| Taux d’erreur extracteur | < 0,5 % |
| Macro-F1 moyen (18 entites) | 0,75+ post-fine-tune |
| VRAM requise (GLiNER batch 8) | 8–12 Go (selon longueur) |
| Outils | Prometheus (queues, duree etapes), OpenTelemetry, traces par `job_id` (sans PII) |

**Fallbacks** : ONNX CPU si GPU saturé ; file "dead letter" + retry exponentiel + circuit breaker sur appels LLM (si jamais utilisé en secours, voir annexe 19).

---

# Partie III — Ingestion multi-format (markdown intermediaire)

## 9. PDF vers Markdown

| Outil | Avantages | Inconvenients |
|-------|-----------|---------------|
| Marker | Qualite "doc layout" | Coût GPU, temps |
| PyMuPDF4LLM | Rapide, fiable | Moins "semantique" sur colonnes |
| Docling (IBM) | Tableaux, structure | Tuning, deps lourds |

- **AcroForm / signature** : détecter et **refuser** la modification in-place (ou stripper avec avertissement legal).  
- **Scan** : détection (ratio texte) -> **PaddleOCR** (FR/EN) ; post-correction dictionnaire.

## 10. DOCX / DOC vers Markdown

- Mammoth, Pandoc, python-docx : combiner (Mammoth pour HTML/MD, Pandoc si macros absentes).  
- **Track changes** : extraire `w:ins` / `w:del` -> soit rejeter, soit appliquer version "finale" uniquement, documente.  
- **Macros** : avertir / bloquer (politique securite).

## 11. EML / MSG

- `mailparser`, `extract_msg` ; RFC822 imbrique -> recursion limitee ( profondeur max 5), pieces jointes -> pipeline comme fichiers.  
- Encodage : normaliser UTF-8, preserver `Message-ID` pour threading en sortie.

## 12. XLSX, CSV, PPTX

- `openpyxl` + `pandas` ; PPTX : `python-pptx` ; `pandas.to_markdown` pour l’étape NER.  
- **Re-ecriture** : conserver onglet + cellule -> mapping pour renderer (id de cellule).

---

# Partie IV — Re-export a l'identique

## 13. PDF spatial (redaction)

- `PyMuPDF` : `add_redact_annot` sur quadrilateres (si `markdownRegions` a page + bbox).  
- Conserver polices integrees ; si police manquante -> embedded subset.  
- **Fallback** : re-render WeasyPrint depuis markdown (perte d’identite pixel, à signaler).

## 14. DOCX (find / replace a preserves styles)

- Parcours `word/document.xml` : remplacer **par runs** en préservant `w:rPr`.  
- Éviter replace global naif sur `full text` (casse le XML).

## 15. EML (reconstruction MIME)

- `email.message.EmailMessage` : recopier headers sûrs, re-attacher pieces jointes anonymisees.  
- `multipart` : reconstruire structure identique (boundary nouveau).

## 16. Validation visuelle

- `pdftotext` + diff ; **SSIM** sur rasterisation page (seuil 0,95) ; comparaison structurelle HTML/MD.  
- Garde-fou : regex **aucune** occurrence des chaînes originales sensibles (échantillon) post-render.

---

# Partie V — Cas limites et modele de menace

## 17. Cas limites et dégradation contrôlée

| Cas | Comportement recommande |
|-----|------------------------|
| PDF chiffré | Refus clair, pas de "hack mdp" |
| PDF signé (certificat) | Avertir invalidation de signature si redaction |
| Scan tres bruité | Option "qualite insuffisante" + re-upload |
| Tableaux XLSX avec formule | Remplacement valeur ou cellule, risque = documenter |
| Mélange FR/EN | Modèle multilingue (GLiNER multi) + langdetect |
| Fichier > 100 pages | Découpage + jobs chaines, quota |

## 18. Menaces, profils "copieurs", concurrence (vue marché)

**Profils** (synthèse) :

1. **Ex-salario ML+backend** (90 jours à parité UX partielle) — 80–120 k€ charges + infra.  
2. **SaaS concurrent** (6–12 mois) — intégration GRC existante, canal partenaires.  
3. **"Script kiddie" + IDE** — UI faible, fuites, pas de DPA, mort commerciale sur grands comptes.  
4. **Auteur d’état / APT** (hors sujet PME) — ciblage politique, pas l’économie du clone.

**Acteurs du marché (anonymisation / données / privacy tech)** : Privacy (éditeurs spécialisés), GRC / legal tech, outils d’"enterprise privacy" (Privitar historique, BigID, OpenText, plateformes de synthèse, etc. — noms commerciaux sujets a évolution). **Forces** : intégration SI, gouvernance, SLA. **Faiblesses** : coût, complexité, pas toujours de **layout preservation** "pixel".

**Barrières a la copie** (non techniques) : **confiance, références clients, assurance cyber, DPA, support juridique**, feuille de route, certification (ISO 27001, HDS si santé, etc.).

| Faciliteur OSS | Rôle |
|---------------|------|
| GLiNER, CamemBERT, Presidio | NER + règles |
| PocketBase, Next.js, Stripe | V1 rapide |
| Marker / Docling / PyMuPDF | Ingestion |

---

# Partie VI — Shopping list & références

## 19. Modèles, jeux de données, paquets, bibliographie (extraits)

### Modèles Hugging Face (noms d’exemple, versionner au build)

- `urchade/gliner_multi-v2.1` — multilingue, zero-shot.  
- `Jean-Baptiste/camembert-ner` — baseline FR (adapter labels).  
- `cmarkea/distilcamembert-base-ner` — allégé CPU.  
- `microsoft/Phi-3.5-mini-instruct` — **jamais** en prod pour PII brutes sans garde-fous (filtrage, audit) ; listé ici uniquement comme **exemple** de LLM "secours" théorique.  

### Datasets (FR / admin / NER)

PIAF, FQuAD, MultiCoNER 2 (FR), CAS / corpus administratifs publies, French NER, WikiNER-fr, etc. — constituer un **mélange domaine-avocat / RH / compta** pour le fine-tune.

### Paquets (épingles indicatives, adapter selon avril 2026)

`marker-pdf>=0.3`, `docling>=1.5`, `pymupdf4llm>=0.0.17`, `presidio-analyzer>=2.2`, `gliner`, `paddleocr>=2.7`, `python-docx>=1.1`, `mailparser`, `weasyprint>=62`, `stanza`, `onnxruntime-gpu` ou `onnxruntime`.

### Bibliographie (exemples DOI / lieux de publication)

- GLiNER : *Generalist Model for Named Entity Recognition* (repositoire + article associé, 2023–2024).  
- Marker, Docling : documentations arXiv / IBM Research.  
- Règles IBAN (ISO 13616) ; Luhn (ISO/IEC 7812).  
- pocketbase.io — modèle d’auth et de realtime.

---

# Partie VII — Défense (SOC) : empreintes d’un "clone" en R&D

## 20. 12 règles SIEM (pattern, seuil, action, faux positifs)

| # | Detection | Seuil / pattern | Action | Faux + |
|---|------------|----------------|--------|--------|
| 1 | Scraping en série des chunks `/_next/static` | > 40 fichiers / 2 min / IP | Rate-limit + capcha | Build lent / SWUpdate |
| 2 | Téléchargement `build manifest` + bundle complet < 60s | 1 IP, ordre presque séquentiel | WAF rule | Test perf CDN |
| 3 | `GET /api/health` | > 20 / min / IP | Ban temporaire | Healthcheck mal configuré |
| 4 | JA3 typique `Python-requests` / `curl` | sur routes utilisateur | Challenge | Outils d’intégration partenaire |
| 5 | ASN cloud scraper | IP datacenter + pas de referer | Review | API-to-API B2B |
| 6 | Même PDF hash léger (padding) re-soumis | rafale | Flag fraude/abus | Outil de test QA |
| 7 | `?fields=schema` en boucle | > 5 / s | Block | Outil admin oublié |
| 8 | `HEAD` séquentiel sur API REST | dictionnaire de chemins | WAF + alerte | Mauvais crawler SEO |
| 9 | Intervalles de requêtes constants (ms) | écart type < 50 ms | Bot score | `k6` interne (whitelist IP) |
| 10 | Dump proxy analytics | toutes requêtes /ph/ en rafale | Throttle | Debug extension |
| 11 | Rafale 401/403 + énumération d’`id` | > 15 / min | Lock account + alerte CSIRT | Utilisateur fatigué (refresh) |
| 12 | Requêtes `swagger`/`graphql` si exposés | 200 + export | Alert critique | Faux positif si doc publique voulue |

*Objectif* : aider Marvin a **distinguer** un audit autorisé d’un sondage abusif.

---

# Partie VIII — Feuille de route, coût, RGPD, anti-réplication des failles d’audit

## 21. Roadmap 7 / 14 / 21 jours, TCO 12 mois, RGPD (rappel)

- **J+7 (MVP lab)** : PDF + GLiNER + redaction + UI minimale. Qualité plafonnée ~**50%** sens métier.  
- **J+14** : DOCX+EML, pseudos serveur, worker GPU, **70%**.  
- **J+21** : 18 entités, SSIM, OCR, observabilité, **~80%** (hors gouvernance).  

**TCO 12 mois (indicatif, France, PME product)** : **85–95 k€** (infra 40–50 k, ML ops + run GPU fine-tune 8–12 k, 0,3 ETP mainteneur, 0,2 ETP support, outillage et licences, assurance).

**RGPD** : hébergement UE, DPA, minimisation, effacement, registre, DPIA, transferts (PostHog US -> SCC + TIA si applicable).

## 22. Ne reproduisez pas les 11 findings F1–F11 (le clone "propre" les corrige)

| ID | Titre (synthèse) | Exigence pour un clone *defensif* |
|----|------------------|----------------------------------|
| F1 | Noms d’env. `BRAIN_*` côté client | Aucun litteral secret/ nom de serv interne en bundle : grep CI |
| F2 | Double hôte `api` / `pb` | Un seul host + 301 + DNS propre |
| F3 | Jetons + pseudos en `localStorage` | Cookies HttpOnly / serveur seulement |
| F4 | `?edit=` ID prévisible | UUID + règles RLS + pas de fuite liste |
| F5 | Pas de WAF / IP exposée | CDN/WAF, masquer origine, rate limit |
| F6 | CORS `*` | Whitelist d’origine stricte |
| F7 | HSTS/CSP hétérogènes | HSTS, CSP, Referrer-Policy homogènes |
| F8 | Enregistreur analytics sur appli doc | Désac. ou masquage total + DPA |
| F9 | Abonnement SSE large | Filtre serveur par `user` |
| F10 | Clés marketing | Rotation, bruit, pas de "secret" |
| F11 | Empreinte build | Pipeline unique (non critique) |

*Source interne d’audit : findings documentes dans le livrable pentest Marvin (F1–F11). Ce blueprint ne re-implemente pas les failles : il rappelle de les supprimer d’un prétendu clone.*

---

# Partie IX — Provisioning infrastructure (étapes concrètes, génériques)

## 23. Compte cloud, région, IP

- Créer organisation / projet **fr-par-** (ou équivalent UE).  
- **IAM** : rôles `deploy`, `s3`, `secret-read` séparés ; **pas** de clés en repo.  
- **GPU** : L4 24 Go pour inference ; 2x instances CPU (API `brain`, `extractor` IO).  
- **IPs flottantes** : front stable ; **reverse DNS** (email transactionnel, SPF).  
- **Pourquoi cloud français / UE** (au-delà d’exemples type Scaleway) : DPA, latence, souveraineté perçue par les clients.  

## 24. DNS, certificats, edge

- Déléguer DNS (Cloudflare, Bunny) ; A/AAAA ; MX ; **SPF, DKIM, DMARC** (TXT).  
- **Let’s Encrypt DNS-01** (wildcard) pour `*.app.example.com`.  
- **HSTS preload** (après stabilisation) ; pas de contenu mixte.  

## 25. Proxy inverse, WAF, CDN

- **Caddy** (simple TLS) ou **Traefik** (labels Docker) ; **OWASP ModSecurity** ou règles WAF managées.  
- **CDN** : assets statiques longue durée, **pas** de cache sur `/api` ; **100 req/min/IP** (ajuster).  

## 26. Stockage objet + cycle de vie

- 3 compartiments : `uploads`, `outputs`, `backups` ; versionnement ; **lifecycle** purge 30j ; **CORS** limité ; URLs **presign 5 min** ; chiffrement SSE.  

## 27. Bases, file, cache

- **PocketBase** (SQLite) pour métier.  
- **Postgres 16** pour audit / analytics.  
- **Redis 7** : streams + verrous de job.  
- **Litestream** -> S3 (RPO **~60s**).  

---

# Partie X — Reproduction front "pixel perfect" (Next.js 14)

## 28. Initialisation

`create-next-app@latest` — TypeScript, ESLint (flat), Tailwind, `src/`, **App Router**, Turbopack. Ajouter shadcn/ui, Framer Motion light.

## 29. Arbre de routes (exemple)

- `/` marketing  
- `/anonymisation` (upload)  
- `/edit/[uuid]` **uniquement UUID** (jamais ID séquentiel)  
- `/pricing`, `/account`  
- `/legal/...`  
- `app/api/.../route.ts` : proxy BFF ver PocketBase (cookies HttpOnly)  

## 30. Design system

- Tokens (couleurs, espacement 4/8/12, radius 8/12), `Inter` via `next/font`, dark/light, breakpoints — **n’imitez pas** assets graphiques d’un concurrent (droits d’auteur) : mêmes **principes** typographiques seulement.

## 31. Composants clés

- `Uploader` (chunk upload, reprise, `Accept` MIME).  
- `MarkdownViewer` (GFM, pas de fuite d’exécution).  
- `EditorSideBySide` (Monaco : rôles, surlignage entités, raccourcis).  
- `EntityPanel` (filtre type, regroupement).  
- `PaymentModal` (Stripe Checkout + retour).  

## 32. i18n + a11y

- `next-intl` (fr par défaut, en) ; `eslint-plugin-jsx-a11y` ; `Pa11y` en CI.  

## 33. SEO + mesure (sans capture de contenu sensible)

- Sitemap, robots, JSON-LD.  
- PostHog **proxifié** + **désenregistrement** sur routes sensibles (cf. F8).  
- Publicités : **CMP** cookies (RGPD) avant tags.  

---

# Partie XI — Backend PocketBase (exhaustif, générique)

## 34. Binaire et déploiement

- Télécharge binaire, `systemd` unit, `EnvironmentFile` pour secrets, sauvegarde S3, HTTPS derrière Caddy, admin UI **non expos** publiquement (VPN admin).  
- OAuth Google / Microsoft (consent ecran) pour login entreprise.  

## 35. Schéma collections (principes RLS)

Pour **chaque** record : champs `owner`, `tenant`, `createdAt`.  
- `listRule: @request.auth.id = user.id` (ou rôle admin).  
- Fichiers : **jamais** de lecture sans token d’**accès** signé côté serveur (courte durée).  
- `app_calls` : champs binaires => références **fichiers** stockés, pas d’**énorme** JSON inline si > seuil.  

## 36. Hooks Go (noms d’idée)

- `OnRecordBeforeCreate` : antivirus (ClamAV), quotas, `Content-Type` réel, taille.  
- `OnRecordAfterCreate` : `XADD` Redis job.  
- `OnRecordBeforeUpdate` : le client ne peut **pas** réécrire `markdownOutput` seul.  
- `OnFileDownloadRequest` : vérification propriétaire + log audit.  

## 37. API BFF (Go embarqué ou service séparé)

- `GET /api/v1/jobs/{id}/status`  
- `GET /api/v1/jobs/{id}/result`  
- `GET /api/v1/jobs/{id}/preview`  
- `GET /api/v1/usage`  
- `POST /api/v1/billing/portal` (Stripe)  

**JWT** access 15 min + refresh `HttpOnly` 7j ; en-têtes `Idempotency-Key` sur créations.  

---

# Partie XII — Auth, facturation, emails

## 38. Authentification

- Magic link (unique, TTL 15 min), table `magic_links`.  
- OAuth (PKCE).  
- TOTP optionnel.  
- Sessions : rotation refresh ; révocation globale par `jti` en liste noire (Redis).  

## 39. Stripe

- `checkout.session.completed` — **vérification signature** ; idempotence `event.id`.  
- `customer.subscription.deleted` — downgrade plan.  
- **Customer Portal** — self-service.  
- Produit = **credits** ou forfait mensuel.  

## 40. Emails (Postmark / Brevo)

- **MJML** : templates versionnés.  
- **SPF, DKIM, DMARC** alignés.  
- Pas de PII inutile dans sujet.  

---

# Partie XIII — Code Python côté "Brain" (spec)

## 41. Outils (uv, qualité)

- `uv venv` ; `ruff` + `mypy` ; `pytest` ; packages épinglés (voir §19).  

## 42. `extractor` (pseudo-coeur)

- Détection `magic` + `mimetypes`.  
- `pdf` : Marker (GPU) -> fallback PyMuPDF4LLM -> si scan, PaddleOCR.  
- `docx` : Mammoth -> MD, nettoyages.  
- `eml` : parser -> corps + pieces jointes en sous-jobs.  
- **Erreurs** : codes stables + message utilisateur.  

## 43. `tokenizer` (Stanza `fr_combined`)

- Conserver `start_char`, `end_char` des tokens pour alignement remplacements.  
- **Unicode** NFC, suppression des caractères invisibles.  

## 44. `sanitizer` (regex haute precision)

- IBAN, SIREN/SIRET, NIR, TVA, cartes, emails, IP, telephones, dates, CP — tests unitaires (hypothèse).  
- Dictionnaire de faux positifs (ex. "SIREN" en contexte pédagogique).  

## 45. `analyzer` (fusion)

- `Presidio` + `GLiNER` + `CamemBERT` (vote / score de confiance).  
- Résolution chevauchement : *interval tree* ; résolution *coref* légère (règles + fenêtre sémantique).  

## 46. `pseudonymizer`

- HMAC (§7) ; stockage chiffré ; export **dé-identifié** seulement par défaut.  
- "Réversibilité" = option contractuelle + double enveloppe.  

## 47. `renderer` + tests post-output

- Pipelines par format.  
- **Vérifs** : SSIM, absence de chaînes d’origine (échantillonnage), logs **sans** contenu sensible.  

---

# Partie XIV — Fine-tuning, active learning, MLOps

## 48. Constitution du corpus (300–500 documents)

- Variété : compta, droit, RH, santé (attention — cadre HDS distinct).  
- **Cohen’s kappa** inter-annotateurs > 0,8.  
- Anonymisation du **corpus d’entraînement** lui-même (meta-exigence).  

## 49. Fine-tune GLiNER

- Hyperparamètres **indicatifs** : batch 16, lr 5e-5, cosinus, 3–5 epochs, accum 2.  
- **GPU** H100 spot 4–6 h (ordre de grandeur) ; Métriques par entité.  

## 50. Fine-tune CamemBERT-NER (large)

- batch 8, lr 2e-5, 4 epochs, weight decay 0,01, early stopping.  
- **Export ONNX** (CPU) pour lots batch nuit.  

## 51. Active learning

- Scores d’incertitude (marge) ; file d’**annotation** hebdo ; retrain planifié.  
- **Dashboards** F1 / entité / drift.  

## 52. MLOps

- **MLflow** (tracking + registry) ; A/B 5% ; rollback si régression.  

---

# Partie XV — DevOps, CI/CD, observabilité, PRA/PCA

## 53. GitHub Actions

- `test` : pytest, ruff, mypy, `npm test`.  
- `build` : `docker buildx` multi-arch, cache.  
- `deploy` : OIDC vers le cloud, pas de clés longue durée.  

## 54. Docker (images minimales)

- **Multi-stages** ; base **distroless** ou `gcr.io/distroless/python3` ; Trivy en CI.  
- **cosign** signature d’image.  

## 55. Deploiement (deux options)

- **Serverless** conteneurs (autoscale) pour pic.  
- **K8s** (Kapsule) si besoin d’HPA, PDB, canary.  

## 56. Observabilité

- Prometheus, Grafana, Loki, Tempo, Sentry.  
- Métriques : profondeur file, `duration_extractor_ms`, `gpu_mem`, échecs par étape.  

## 57. Audit & compliance logging

- **Append-only** `audit_log` (Postgres) ; PII chiffrée ou hachée ; export DSAR.  

## 58. PRA/PCA (indicatifs)

- RPO 60s (Litestream), RTO 15 min (instance seconde), tests **trimestriels** ; copie S3 inter-région.  

---

# Partie XVI — Tests (pyramide complète)

## 59. Unitaires

- `pytest` + `coverage` > 80 % cœur.  
- `hypothesis` sur regex.  

## 60. Intégration

- `testcontainers` (Redis, Postgres) ; 50 **documents seed** (voir annexe A3).  

## 61. E2E (Playwright)

- 12 parcours (compte, upload, NER, édition, payement, logout…).  
- **Percy** ou équivalent : régression visuelle.  

## 62. Benchmarks NER

- F1, précision, rappel par entité.  
- **Coût** moyen par doc (GPU secondes * tarif + amortissement).  

## 63. Charge (Locust)

- Scénarios 100 / 1 000 / 10 000 **docs/h** (cible théorique) ; repérer goulot d’étranglement.  

---

# Partie XVII — Go-to-market (ton d’alerte) et limites legales

## 64. Page d’atterrissage (principes)

- Message **souveraineté** / **RGPD** (sans usurpation) ; vitesse (LCP, CLS) — **Lighthouse 95+**.  

## 65. SEO (contenu long terme, ethique)

- Mots clés informatifs ; blog expert ; liens obtenus **légitimement** (partenariats).  

## 66. Annonces (Google / LinkedIn)

- Ciblage par mots clés (pas d’encheres sur la marque d’autrui en violation des CG des plateformes) ; transparence légale publicitaire.  
- *Ne pas* mettre en œuvre de **retargeting** sur la base d’exploitation de données **sans** consentement (RGPD / ePrivacy). Le présent chapitre reste un **avertissement** : certains scénarios marketing agressifs sont **interdits** et expose à sanctions.  

## 67. Migration "clientèle" : scenarii d’abus (Avertissement juridique)

**Avertissement** : toute prospection automatisée, scraping de donnees personnelles ou harcelement d’intérimaires d’un concurrent peut violer le **RGPD**, le **droit a la non-prospection** (L.34-5 du *Code de la consommation*), la **concurrence déloyale** et les *Conditions Générales* des reseaux sociaux.  
- **Mise en pratique légale pour Marvin** : anticiper **clauses de non-sollicitation** raisonnables (selon le droit applicable), rappels internes, protection des listes de clients (secret des affaires).  
- Ce chapitre ne constitue **pas** un mode d’emploi d’ingérence.  

## 68. "Anti-empreintes" vues côté défense (détecter, pas aider a masquer l’illégalite)

- Les contournements de WAF, les réseaux Tor pour **masquer l’illégalité** sont des **indicateurs** pour un SOC, pas un mandat.  
- Marvin : corréler **JA3, ASN, taux 401, motif de navigation** (règles §20).  

---

# Annexes

## A1 — Compilation de pseudo-code (services, extraits, sans credentials)

*Pedagogique uniquement. Ne constitue pas un PoC deplacable "tel quel" en production (manque de secrets, de politiques, de tests, de deploiement).*

**extractor (Python, squelette)**

```python
def detect_mime(path: bytes) -> str:
    # libmagic + extension + mimetypes.guess
    return sniff(path)

def extract_to_markdown(file_path: str) -> tuple[str, Meta]:
    mime = detect_mime(read_head(file_path))
    if mime == "application/pdf":
        if is_encrypted(file_path):
            raise EncryptedUserDocument("Fournir version non chiffree / mot de passe via flux securise")
        if is_scanned(file_path):
            return ocr_to_md_ocrmypy_then_paddle(file_path)
        return run_marker_with_fallback_pymupdf4llm(file_path)
    if mime in {DOCX_MIME}:
        return mammoth_to_md_and_strip_macros(file_path)
    if mime in {EML_MIME, MSG_MIME}:
        return email_tree_to_markdown(file_path, depth=0, max_depth=5)
    if mime in {XLSX_MIME, CSV_MIME}:
        return table_to_markdown_sheets(file_path)
    if mime in {PPTX_MIME}:
        return pptx_slides_to_markdown(file_path)
    raise UnsupportedFormat(mime)
```

**tokenizer (Stanza, offsets)**

```python
def tokenize_french_with_offsets(text: str) -> list[TokenSpan]:
    nlp = stanza.Pipeline("fr", processors="tokenize,mwt", tokenize_pretokenized=False)
    doc = nlp(unicodedata.normalize("NFC", text))
    out = []
    for s in doc.sentences:
        for t in s.tokens:
            out.append(TokenSpan(s.text, t.start_char, t.end_char))
    return out
```

**sanitizer (regex haute confiance, illustrations)**

```python
def luhn(s: str) -> bool: ...
def iban_check(s: str) -> bool: ...
def find_high_precision_spans(text: str) -> list[Span]:
    out = []
    for m in re.finditer(IBAN_RE, text):
        if iban_check(m.group(0)):
            out.append(Span("IBAN", m.start(), m.end(), 0.99))
    for m in re.finditer(SIRET_RE, text):
        if luhn_14(m.group(0)):
            out.append(Span("CID", m.start(), m.end(), 0.98))
    return merge_intervals_with_model(out)
```

**analyzer (GLiNER + second modele, fusion)**

```python
def run_ner_fusion(md_text: str, selected: set[str]) -> list[Entity]:
    gliner_out = run_gliner(md_text, labels=selected, threshold=0.5)
    camembert_out = run_camembert_ner_if_needed(md_text, selected)  # optionnel, CPU/ batch
    regex_out = find_high_precision_spans(md_text)
    merged = vote_merge([gliner_out, camembert_out, regex_out])
    return resolve_overlaps(merged)  # interval tree

def resolve_overlaps(entities: list[Entity]) -> list[Entity]:
    # Trier par confiance, retirer doublon geographique, conserver l'etiquette la plus fiable
    ...
```

**pseudonymizer (deterministe + stockage chiffre)**

```python
def make_group_key(coref: CorefHint, ent: Entity) -> str: ...

def assign_pseudo(ent: Entity, group_key: str, ctx: RequestContext) -> str:
    raw = f"{ctx.tenant}|{ent.type}|{group_key}".encode()
    tok = hmac.new(ctx.hmac_master, raw, hashlib.sha256).hexdigest()[:8]
    return f"{ent.type.lower()}_{tok}"
```

**renderer (orchestrateur format)**

```python
def render(job: Job) -> str:
    fmt = job.source_format
    if fmt == "pdf":
        return redact_pdf_spatial(job) or rerender_from_md(job)
    if fmt == "docx":
        return redact_docx_preserve_runs(job)
    if fmt == "eml":
        return rebuild_mime_multipart(job)
    if fmt in ("xlsx", "csv"):
        return write_back_cells_from_mapping(job)
    raise UnsupportedExport(fmt)
```

**analyzer (raccourci, boucle d'appel)**

```python
def run_ner(text: str) -> list[Entity]:
    intervals = []
    for span in gliner(text, threshold=0.5):
        intervals.append(merge_with_regex(span, sanitizer_hits(text)))
    return resolve_overlaps(intervals)
```

**Boucle worker (illustration)**

```python
async def worker_loop():
    while True:
        job = await redis.blpop("brain:queue")
        try:
            md, meta = extract_to_markdown(job.in_path)
            toks = tokenize_french_with_offsets(md)
            hygiened = run_sanitizer_pass(md)
            ents = run_ner_fusion(hygiened, job.selected_entities)
            pmap = build_pseudo_map(ents, job)
            out_path = render_apply(job, pmap)
            await pocketbase.update_job_done(job.id, out_path)
        except Exception as e:
            await pocketbase.update_job_failed(job.id, code="EXTRACT" if "extract" in str(e) else "UNKNOWN")
```

## A2 — Diagrammes Mermaid (a–e)

### (a) Composants (clone défensif)

```mermaid
flowchart TB
  FE[Nextjs]
  BFF[Route_handlers]
  PB[PocketBase]
  R[Redis_Streams]
  W[Brain_Worker]
  GPU[GPU_L4]
  S3[Object_Storage]
  FE --> BFF
  BFF --> PB
  BFF --> S3
  PB --> R
  R --> W
  W --> GPU
  W --> PB
```

### (b) Séquence job

```mermaid
sequenceDiagram
  participant U as User
  participant N as Next_BFF
  participant P as PocketBase
  participant R as Redis
  participant W as Worker
  U->>N: upload
  N->>P: create job
  P->>R: enqueue
  W->>R: consume
  W->>P: write outputs
  U->>N: poll_SSE status
  N-->>U: file_ready
```

### (c) Paiement Stripe (vue simplifié)

```mermaid
sequenceDiagram
  participant U
  participant N
  participant S as Stripe
  U->>N: checkout
  N->>S: session
  S-->>N: redirect success
  S->>N: webhook (signed)
  N->>N: idempotent apply
```

### (d) Topologie (Scaleway, générique)

```mermaid
flowchart LR
  CF[Cloudflare]
  C[Caddy]
  A[Autoscale_Services]
  R[Redis_Private]
  D[Postgres_Private]
  O[S3_Private]
  CF --> C
  C --> A
  A --> R
  A --> D
  A --> O
```

### (e) Flux RGPD (DSAR, schéma)

```mermaid
flowchart TB
  U[Data_subjet]
  I[Request_portal]
  P[Orga_RBAC]
  E[Export_chiffre]
  U --> I
  I --> P
  P --> E
```

## A3 — Recette de validation (50 documents, métriques)

- **Echantillons** : 10 PDF (texte + scan), 10 DOCX (simple + tableau), 10 EML (pieces jointes), 10 XLSX, 10 mixtes.  
- **Par document** : latence, SSIM, F1 moyen pondéré, taux d’*échec* extract.  
- **Cibles** : SSIM > 0,95 la ou applicable ; 0 fuite d’*échantillons* de texte d’origine en sortie.  

## A4 — Checklist pré-production (100 items)

*Cocher par l’equipe prod avant `go-live` (clone defensif).*

**Infra / reseau (1–15)** : 1 TLS 1.2+ partout 2 certificats renouveles auto 3 HSTS 4 redirect HTTP->HTTPS 5 WAF regles 6 rate-limit global 7 rate-limit /tenant 8 CDN assets 9 prive reseau DB/Redis 10 SSH bastion 11 pare-feu sortant 12 DNSSEC optionnel 13 DDoS plan 14 IP allowlist admin 15 sonde sante externe.  

**Stockage (16–25)** : 16 S3 prive 17 CORS restreint 18 lifecycle 30j 19 chiffrement SSE 20 versionnement 21 ACL min 22 acces signe 23 scan antivirus entree 24 quota taille 25 integrite `sha256`.  

**PocketBase / BaaS (26–40)** : 26 RLS toutes tables 27 pas de CORS * 28 admin VPN 29 hooks validation MIME 30 hooks quota 31 fichiers separes gros binaires 32 `viewRule` owner 33 pas de fuite `list` 34 test IDOR 35 webhook Stripe verif 36 `audit_log` 37 rotation JWT 38 `refresh` HttpOnly 39 revocation session 40 backup Litestream.  

**App Next (41–50)** : 41 pas de `NEXT_PUBLIC` secrets 42 CSP stricte 43 SRI cdn 44 pas d’inline 45 cookies SameSite 46 CSRF 47 validation Zod 48 error boundaries 49 pas d’XSS 50 Lighthouse perf.  

**ML / Donnees (51–60)** : 51 modeles pin versions 52 pas de PII en logs train 53 MLflow prive 54 reproductibilite 55 drift 56 fairness note 57 export ONNX 58 GPU out-of-mem 59 fallback CPU 60 cadrage SLO inference.  

**Observabilite (61–70)** : 61 Prometheus 62 Grafana 63 Loki 64 Tempo 65 Sentry 66 alerte queue 67 alerte GPU 68 SLO 99% 69 journal sans PII 70 retention.  

**CI/CD (71–80)** : 71 OIDC 72 Trivy 73 cosign 74 multi-stage 75 tag semver 76 rollback 77 feature flags 78 tests charge 79 secrets vault 80 SBOM.  

**Legal (81–90)** : 81 DPIA 82 DPA 83 SCC 84 TIA 85 mentions 86 ToS 87 cookie CMP 88 DSAR 89 CIL / DPO 90 registre.  

**Support / Run (91–100)** : 91 runbook P1 92 contact sec 93 on-call 94 plan comm 95 SLA 96 formation support 97 FAQ 98 statut public 99 post-mortem 100 exercice PRA/PCA annuel.  

## A5 — Ontologie 18 entités (ligne par ligne, exemples entièrement fictifs)

| Code | Definition | Exemples fictifs (3) | Piste detection | F1 cible* | Gotchas |
|------|------------|----------------------|-----------------|-----------|--------|
| PR | Personne physique | "M. Herve MARTIN" ; "Me Sophie DURAND" ; "Mme Claire PETIT" | NER + civilités + titres (Me, Dr) | 0,78–0,85 | Faux noms d’entreprise contenant "Martin SA" |
| MAIL | E-mail | `client@exemple.fr` ; `a+b@courrier.example` | pattern RFC + liste blanche interne (noreply) | 0,88–0,93 | Adresses en URL |
| PHON | Telephone | 06 12 34 56 78 ; +33 1 40 00 00 00 ; 0033… | E.164 + dictionnaire pays | 0,82–0,88 | Numeros de ligne courts (3–4 chiffres) |
| CIE | Societe / enseigne | "ACME SARL" ; "Widget SA" | lexiques NER + formes legales | 0,72–0,80 | Homonymie personne/PME |
| ORG | Organisation (non-PME) | "Association des Amis" ; "Fondation Exemple" | NER + mots cles (association…) | 0,70–0,78 | Sigles d’etat |
| ACT | Acteur (role contractuel) | "Le prestataire" en debut de paragraphe (contexte) | coreference + NER | 0,65–0,75 | Tres dependant du corpus |
| CID | Identifiants (SIREN, SIRET, n° de dossier) | 552 100 554 ; 55210055400012 ; n° 2025-001 | SIREN/SIRET, regex contextuelles, identifiants longs alphanum | 0,75–0,85 | Numeros d’art. de loi |
| ADR | Adresse postale | "12 rue Fictive, 75000 Metropole" | NER + parseur d’adresse | 0,75–0,83 | "Paris" isole -> LOC/ADR |
| LOC | Toponyme (ville, region) | "Bordeaux" ; "Nouvelle-Aquitaine" | gazetteer + NER | 0,72–0,80 | Homonyme entreprise "Bordeaux SA" |
| URL | Lien | `https://exemple.com/doc` | regex URL | 0,85–0,92 | Liens raccourcis (redirect) |
| IP | Adresse IP | 203.0.113.4 ; 2001:db8::1 | v4 / v6 | 0,88–0,94 | IPv4 en code commande |
| IBAN | Compte bancaire international | `FR76 1234 5678 9012 3456 7890 123` | MOD-97, pays | 0,90–0,95 | Iban d’entrainement, tests |
| CARD | Numero de carte bancaire | 4532 **** **** 1234 (Luhn) | Luhn, longueur, BIN | 0,88–0,95 | Numeros 16 chiffres non-bancaires |
| REF | Reference interne / dossier | "REF-2025-000123" ; "Contract #456" | heuristiques alphanum | 0,65–0,75 | Reference legale d’article |
| FILE | Fichier / chemin resiliant PII | `\\fileserve\\contrats\\client.pdf` | chemins, UNC | 0,70–0,80 | Faux positif chemins install |
| FRNIR | Numero d’inscription (NIR) | 1 99 12 2A 456 123 45 (fictif) | cle, format, doublon naissance | 0,80–0,90 | Saisie partielle, erreurs de frappe |
| DT | Date (naissance, echeance) | 12/04/1990 ; le 1er juillet 2024 | grammaire date FR + NER | 0,75–0,83 | Dates contractuelles non sensibles |
| CP | Code postal (FR) | 75012 ; 13001 | regex 5 chiffres + CORSICA | 0,88–0,93 | Combiné avec adresse a reconstruire |

*F1 cible = apres ajustement domaine — pas d’engagement chiffre.

*Gotchas globaux* : chevauchement ADR+LOC+CP ; SIREN dans URL ; noms d’*office* (La Poste) ; *tracked changes* en DOCX.

## A6 — ADR (12 décisions)

1. **PocketBase vs Supabase** : binaire + simplicité d’hébergement + fichiers = PB ; gouvernance RLS a renforcer.  
2. **GLiNER** primaire, **CamemBERT** seconde opinion (vote).  
3. **Marker** si qualité, **Docling** si gouvernance IBM, **PyMuPDF4LLM** par défaut budget.  
4. **Stripe** (standard industrie) vs *Lemon* (SaaS indie).  
5. **Magic link** par défaut, mot de passe = option rare.  
6. **Fournisseur UE** d’hébergement (perception DPA) vs *US pure player*.  
7. **Caddy** (simplicité) **vs** **Traefik** (labels K8s).  
8. **Postmark** (delivrabilité) vs *Brevo* (prix) — *SPF* etc. requis.  
9. **Litestream** (SQLite) vs *pg* backup classique.  
10. **MLflow** (OSS) vs *W\&B* (cloud).  
11. **Playwright** (multi navigateur) vs *Cypress*.  
12. **PostHog** (fonctionnel riche) vs *Plausible* (confidentialite par design) + risque d’*enregistreur* (gérer, cf. F8).  

## A7 — Exemples de **commandes d’entraînement** (à adapter, sans clés, environnement sûr)

```bash
# (Illustration) entraîner un adaptateur de classification sur JSONL labelise
# python -m gliner_finetune --train data/train.jsonl --out ./artifacts/gliner-ft
# (Ne pas lancer ici - pipeline interne, GPU requis, versions pin)
```

*Évaluation* : `seqeval` / *sklearn* sur spans ; export ONNX : `optimum` / `onnxscript`.  

*Benchmark* L4 vs H100 (ordre de grandeur) : H100 2-3x plus rapide en entraînement BF16, coût spot variable.

## A8 — Migration / repli (Feature flags)

- **Flags** : *Unleash* / *Flagsmith* (self-host) ; critères d’*activation canary* : erreurs < 0,2 %, latence p99 stable.  
- **Rollback** < 5 min : revenir feature flag + image Docker N-1.  
- **Modèle d’*incident* :** *timeline root cause* + *actionnable*.  

## A9 — Modèle (structure) de DPA (FR — extraits a faire relater par le juridique)

- Parties, objet, duree, nature des données (PII), lieux de traitement (UE), **sous-traitants** (liste annexe, notification préalable), **mesures** techniques (chiffrement, accès, audit), **sous-traitance ultérieure**, **transfert hors UE** (SCC, TIA), **incident** PII (notification 72h), **effacement** fin de contrat, **audit** annuel, **DPA* Signataires, loi et juridiction.  
- **Ne constitue pas** un acte juridique signé.  

## A10 — Manuel utilisateur (8 étapes) + 25 questions FAQ (extraits)

**Étapes** : 1) Créer compte, 2) vérifier email, 3) uploader, 4) choisir entités, 5) lancer, 6) vérifier / éditer, 7) payer / utiliser crédit, 8) exporter et **supprimer** le fichier source si besoin.  

**FAQ (échantillon)** : formats ? taille max ? RGPD ? hébergeur ? *réversibilité* ? export juridique ? support ? SLA ?  

---

# Document termine (avril 2026)

*Ce fichier est la version Markdown maitre du "Blueprint v3" pour l’exemplaire **Marvin Systems** (ton d’alerte, mesures de défense). Aucun secret d’infrastructure, aucun code clé-en-main, aucune incitation a la violation de loi.*
