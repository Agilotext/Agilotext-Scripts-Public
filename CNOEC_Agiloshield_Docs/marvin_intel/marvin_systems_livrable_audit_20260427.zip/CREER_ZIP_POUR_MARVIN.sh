#!/usr/bin/env bash
# Cree une archive a transmettre a Marvin Systems (sans le dossier INTERNE Agilotext).
# Usage: ./CREER_ZIP_POUR_MARVIN.sh  (depuis ce repertoire)

set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PARENT="$(cd "$HERE/.." && pwd)"
STAMP=$(date +%Y%m%d)
ZIPNAME="marvin_systems_livrable_audit_${STAMP}.zip"
OUT="$PARENT/$ZIPNAME"

cd "$HERE"
zip -r "$OUT" \
  LISEZMOI.md \
  MANIFEST_FICHIERS.md \
  CREER_ZIP_POUR_MARVIN.sh \
  A_HAR_fichier_source \
  B_preuves_brutes_HAR \
  C_architecture_backend \
  D_audit_securite_findings_rapports \
  E_blueprint_defensif_reproductibilite \
  F_synthese_tables_clefs

echo "Archive creee: $OUT"
ls -la "$OUT"
