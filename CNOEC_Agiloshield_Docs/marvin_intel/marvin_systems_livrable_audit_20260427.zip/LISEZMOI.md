# Dossier complet — Marvin Systems (audit et livrables)

**Emplacement** : `marvin_intel/marvin_systems_dossier_complet_2026/`  
**Date de constitution** : avril 2026  
**Usage** : classement unique de toutes les informations produites dans le cadre de la prestation (audit passif, architecture, sécurité, HAR, blueprint défensif).

## Contenu par sous-dossier

| Dossier | Contenu |
|---------|---------|
| **A_HAR_fichier_source** | Fichier `marvin-systems.com.har` (copie depuis le poste auditeur) + note de confidentialité |
| **B_preuves_brutes_HAR** | `RAW_EVIDENCE.md` + **`RAW_FINDINGS_2026-04-27.md`** (preuve vs inférence, manips, curl) |
| **C_architecture_backend** | `MARVIN_BACKEND_DECODED.md` + **`MARVIN_ARCHITECTURE_DECODED.md`** (synthèse, nuance MD + régions) |
| **D_audit_securite_findings_rapports** | `FINDINGS_PENTEST_MARVIN.md` + rapports pentest exécutif et technique (`.md` + `.pdf`) |
| **E_blueprint_defensif_reproductibilite** | `MARVIN_CLONE_BLUEPRINT_2026.md` + PDF associé (étude défensive « barrières à lever ») |
| **F_synthese_tables_clefs** | `SYNTHESE_GLOBALE_cles_fuites_indicateurs.md` — tableau unique de synthèse |
| **INTERNE_AGILOTEXT_ne_pas_envoyer_a_Marvin** | Positionnement produit Agilotext / Anon2 — **ne pas inclure** dans le zip client |

## Fichiers à la racine de ce dossier

- `LISEZMOI.md` (ce fichier)
- `MANIFEST_FICHIERS.md` — inventaire exhaustif des fichiers
- `CREER_ZIP_POUR_MARVIN.sh` — script pour générer une archive **destinée à Marvin** (sans le sous-dossier interne)

## Zip à transmettre à Marvin Systems

Exécuter depuis ce répertoire :

```bash
chmod +x CREER_ZIP_POUR_MARVIN.sh
./CREER_ZIP_POUR_MARVIN.sh
```

Cela produit `marvin_systems_livrable_audit_YYYYMMDD.zip` dans le répertoire parent (`marvin_intel/`), contenant HAR, preuves, architecture, audit, blueprint — **sans** le dossier `INTERNE_AGILOTEXT_ne_pas_envoyer_a_Marvin`.

> **Confidentialité** : le fichier `.har` peut contenir des cookies, jetons de session ou paramètres d’URL sensibles. À transmettre par canal sécurisé (S/MIME, coffre-fort, lien à accès restreint). Marvin doit traiter ce fichier comme **preuve technique** et non comme document public.

## Source HAR sur le poste auditeur

Copie de référence utilisée : `~/Downloads/marvin-systems.com.har`  
En cas de mise à jour, remplacer le fichier dans `A_HAR_fichier_source/` et régénérer le zip.

---

*Index maintenu pour l’équipe Agilotext (documentation CNOEC / Agiloshield).*
