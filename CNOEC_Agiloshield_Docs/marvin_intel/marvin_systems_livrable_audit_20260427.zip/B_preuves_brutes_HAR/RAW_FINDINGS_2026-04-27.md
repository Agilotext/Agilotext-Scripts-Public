# Findings bruts et analyse à chaud — 2026-04-27

**Source principale** : capture HTTP `marvin-systems.com.har` (auditeur), extraits de bundles JS publics, [RAW_EVIDENCE.md](RAW_EVIDENCE.md).  
**Usage** : archivage de traçabilité ; ne remplace pas un rapport d’audit formel.  
**Note légale** : aucune attaque, aucun contournement d’authentification ; observation passive uniquement.

---

## A. Niveau de preuve (à lire avant tout le reste)

| Affirmation | Niveau | Détail |
|-------------|--------|--------|
| API = PocketBase (routes `collections`, `files`, `realtime`) | **Prouvé** (HAR) | Signature REST + chemins + IDs `pbc_*` / records 15 caractères |
| Hébergement ≈ Scaleway Paris (IP `51.158.124.96`) | **Prouvé** (HAR) | `serverIPAddress` sur requêtes |
| Un job = une collection `app_calls` ; champs `extractor*`, `analyzer*`, `markdown*`, `occurrences` | **Prouvé** (réponses JSON HAR) | Schéma visible dans POST/GET `records` |
| Pipeline : étape *extract* puis *analyze* (chunked) | **Très fortement inféré** | Noms de champs + compteurs de chunks |
| `edit=` dans l’URL = ID d’enregistrement | **Prouvé** (navigation + HAR) | Pattern `?edit=7s4c4oyl576966e` |
| Risque IDOR = ID devinable + règles lâches | **Hypothèse de test** (audit actif) | Non validé en profondeur sans mandat d’intrusion |
| Tout le NLP se fait *uniquement* sur le MD sans jamais de coordonnées | **Faux** à formuler ainsi | Champs `markdownRegions`, `redactionRegions` prouvent une **couche de régions** (structure/spatial pour appliquer la sortie). Voir [MARVIN_ARCHITECTURE_DECODED.md](MARVIN_ARCHITECTURE_DECODED.md) section « Nuance » |
| Moteur PDF→MD = Marker / PyMuPDF / etc. | **Non prouvé** (HAR seul) | Aucun header `X-Extractor-Engine` ; voir manips A/B/C |
| URL interne exacte du service « BRAIN » | **Non prouvé** (bundles) | Noms d’env `BRAIN_*` sans valeur inline dans les extraits analysés |
| Clé PostHog « phc_… » | **Prouvé** (bundle / proxy) | Clé **projet** côté client (usage analytics standard, à traiter DPA) |

**Conclusion honnête** : le HAR et les JSON suffisent à **démontrer l’ossature** (BaaS, modèle de données, flux, ontologie, headers). On **ne** « sait **pas** avec certitude *quel* binaire de conversion PDF (Marker, Docling, PyMuPDF4LLM) ni *quel* modèle NER **exact** côtet serveur sans logs serveur, reverse du worker, ou capture réseau **pendant** un traitement montrant un appel vers un hôte externe (Manip C).

---

## B. Endpoints confirmés (échantillons HAR)

```
POST   /api/collections/app_calls/records
GET    /api/collections/app_calls/records/{id}
GET    /api/files/pbc_614331130/{id}/markdown_input_*.md?token=...
GET    /api/files/pbc_614331130/{id}/markdown_output_*.md?token=...
GET    /api/files/pbc_614331130/{id}/markdown_regions_*.json?token=...
POST   /api/realtime   (abonnement SSE)
```

- `pbc_614331130` = `collectionId` PocketBase (préfixe `pbc_` documenté côté PocketBase récent).  
- Exemple d’`id` d’enregistrement (session d’audit) : `7s4c4oyl576966e` (format 15 caractères).

---

## C. Schéma logique de l’enregistrement `app_calls` (agrégat des réponses HAR)

Les champs ci-dessous sont issus d’assemblage des réponses **documentées** dans [RAW_EVIDENCE.md](RAW_EVIDENCE.md) et des analyses de session. **Ce n’est pas** une exportation de la console admin PocketBase : les types exacts (relation vs fichier) peuvent varier.

| Zone | Champs (exhaustif fonctionnel) |
|------|----------------------------------|
| Identité | `id`, `collectionId`, `collectionName` (`app_calls`) |
| Pipeline extracteur | `extractorCompletedChunks`, `extractorTotalChunks`, `extractorDuration` |
| Pipeline analyzeur NER | `analyzerCompletedChunks`, `analyzerTotalChunks`, `analyzerDuration` |
| Fichiers / contenu | `originalInput`, `originalOutput`, `filename`, `filetype`, `fileWeight` ; `markdownInput`, `markdownOutput`, `markdownRegions`, `markdownWeight` |
| Texte intermédiaire | `tokenizedInput`, `sanitizedInput` |
| Régions / rédaction | `redactionRegions`, `customRedactionRegions` |
| Détection & édition | `occurrences`, `editedOccurrences` ; `selectedEntities` (18 clés) |
| Pseudonymisation | `pseudonyms`, `sessionPseudonyms`, `pseudonymGroups`, `awaitsPseudonymization`, `finalizePseudonymization` |
| Accès & édition | `user`, `password`, `whitelist`, `blacklist`, `isSampleFile`, `isEditing`, `wasEdited` |
| Métier | `credits`, `processor` (ex. `anonymize`), `error` |
| Horaires | `created`, `updated` |

---

## D. Les 18 entités (`selectedEntities`) — liste de référence

> Ne pas confondre avec un tag « JOB » (poste) : la liste HAR documentée utilise **ACT** (activité / rôle), pas `JOB` séparé.

```
PR, MAIL, PHON, CIE, ORG, ACT, CID, ADR, LOC, URL, IP, IBAN, CARD, REF, FILE, FRNIR, DT, CP
```

- **CID** agrège SIRET, TVA, références contractuelles selon le contexte (pas de clés `SIRET` / `TVA_FR` séparées côté payload observé).  
- **FRNIR** = NIR français (détecteur ciblé attendu côté moteur).

---

## E. Découvertes « produit / UX » (URL)

- `edit_view=markdown` dans l’URL d’édition : le mode markdown est **exposé** comme vue (pas seulement un détail d’implémentation).  
- Next.js App Router : présence de `?_rsc=` cohérente avec RSC.  
- Turbopack : bundles nommés `turbopack-*.js` (observé sur le site).  
- PostHog (proxy `marvin-systems.com/ph/`) : enregistreur de session côté bundle — risque RGPD (finding F8).  
- Google Ads : `AW-17930965111` + label de conversion (cf. [RAW_EVIDENCE](RAW_EVIDENCE.md) section 9) — suivi d’inscription / marketing.

**Clé PostHog côté client (format `phc_...`)** : exposée en usage normal PostHog ; le risque n’est pas la « fuite d’un secret API serveur » mais l’**exposition de parcours** + configuration du masquage. Ne pas republier hors équipe de travail.

---

## F. Ce qui manque pour « 100 % du puzzle » (recommandation honnête)

| Manque | Manipulation passive recommandée |
|--------|----------------------------------|
| Contenu exact de `markdown_regions_*.json` (schéma offset / pages) | **Manip A** : Network → requête `markdown_regions_*.json` → copier le JSON (Preview) |
| Chaîne d’upload (multipart) et moment où `originalInput` est lié | **Manip B** : Preserve log, upload 1 page, capture POST + headers |
| Appels sortants (LLM, HF, etc.) **pendant** le traitement | **Manip C** : filtrer le réseau 10–20 s ; noter hôtes externes (si aucun, traitement 100 % interne) |

Ces manips se font sur **votre propre compte** dans le produit, pas comme tiers non authentifié.

---

## G. Vérifications réseau passives (légales) — 4 requêtes

À exécuter depuis une machine, **sans** contourner d’authentification ; uniquement des endpoints publics documentés PocketBase / HTTP.

```bash
# Santé + version éventuelle PocketBase
curl -sS "https://api.marvin-systems.com/api/health" | head -c 2000; echo

# En-têtes (HSTS, CORS, etc.)
curl -sI "https://api.marvin-systems.com/api/health"
curl -sI "https://api.marvin-systems.com/api/collections/app_calls/records"
curl -sI "https://api.marvin-systems.com/_/"
```

Interprétation : `/_/`, `/api/health` sont des emplacements **courants** sur PocketBase ; l’**accessibilité** de `/_` en administration doit être vérifiée côté déploiement (ne jamais exposer l’admin en public). Les **codes** 200/401/403/404 informent sur la surface, pas sur une « faille ».

---

## H. Poursuite de la chasse aux `.map` ?

**Non prioritaire** : en production, les source maps sont souvent **désactivées** ou filtrées. L’intelligence d’**architecture** est déjà portée par le HAR (schéma, flux) et le JS (noms de clés, constantes). Le gain marginal vs risque d’heuristique légale/contractuelle d’ingénierie inverse est **faible** par rapport aux manips A/B/C côté réseau applicatif.

---

*Document complété le 2026-04-27. Voir [MARVIN_ARCHITECTURE_DECODED.md](MARVIN_ARCHITECTURE_DECODED.md) pour la synthèse structurante et le pivot Anon2.*
