# Preuves brutes (sources hors workspace)

Fichier source de capture : `marvin-systems.com.har` (repertoire Telechargements de l'auditeur).  
Fichier source JS statique : sauvegarde HTML offline `Anonymisation de documents - Traitement securise de texte et fichiers _ Marvin Systems.html` + dossier `*_files/`.

> **Confidentialite** : ce document ne reprend pas de contenu binaire PDF complet, ni d'adresses e-mail de tiers. Les identifiants techniques ci-dessous proviennent d'une session d'audit enregistree (IDs de jobs, noms de fichiers de test).

## 1. Hote d'API et reseau

| Observable | Valeur (HAR) |
|------------|--------------|
| Host API actif | `api.marvin-systems.com` |
| `serverIPAddress` (plusieurs requetes) | `51.158.124.96` (Online SAS / Scaleway, Paris) |
| HTTP | HTTP/2 sur les reponses echantillonnees |
| `alt-svc` | `h3=":443"; ma=2592000` (HTTP/3 annonce) |
| `content-encoding` | `zstd` (reponses API JSON) |

## 2. Endpoints PocketBase / collections

Echantillons d'URL observees (HAR) :

- `POST https://api.marvin-systems.com/api/collections/app_calls/records` (upload multipart, creation d'enregistrement)
- `GET/PATCH https://api.marvin-systems.com/api/collections/app_calls/records/7s4c4oyl576966e` (id d'echantillon de session d'audit)
- `GET https://api.marvin-systems.com/api/files/pbc_614331130/7s4c4oyl576966e/markdown_input_*.md?token=...`
- `GET https://api.marvin-systems.com/api/files/pbc_614331130/7s4c4oyl576966e/markdown_output_*.md?token=...`
- `GET https://api.marvin-systems.com/api/files/pbc_614331130/7s4c4oyl576966e/markdown_regions_*.json?token=...`
- `POST https://api.marvin-systems.com/api/realtime` (souscription temps reel)

Souscription SSE (corps reponse) :

- `{"clientId":"...","subscriptions":["app_calls/*"]}` puis plus tard `["app_calls/*","app_calls/7s4c4oyl576966e"]`

## 3. Collection `app_calls` (PocketBase)

- `collectionName` : `app_calls`
- `collectionId` : `pbc_614331130`
- `id` d'enregistrement (exemple) : `7s4c4oyl576966e`

## 4. Champs cles d'un enregistrement (JSON reponse, statuts successifs)

Champs repertories dans les reponses (creation puis apres traitement) :

- Pipeline : `extractorCompletedChunks`, `extractorTotalChunks`, `extractorDuration`, `analyzerCompletedChunks`, `analyzerTotalChunks`, `analyzerDuration`
- Fichiers : `originalInput` (nom de fichier stocke), `markdownInput`, `markdownOutput`, `markdownRegions`, `markdownWeight`, `fileWeight`, `filetype`
- Texte : `tokenizedInput`, `sanitizedInput`, `redactionRegions`, `customRedactionRegions`
- Anonymisation : `processor` (`anonymize`), `selectedEntities` (tableau de types), `occurrences` (dictionnaire type -> listes d'exemples detectes)
- Metier : `credits`, `password` (champ), `whitelist`, `blacklist`, `pseudonyms`, `sessionPseudonyms`, `pseudonymGroups`, `awaitsPseudonymization`, `finalizePseudonymization`
- Edition : `wasEdited`, `isEditing`, `editedOccurrences`
- Divers : `user`, `error`, `isSampleFile`, `created`, `updated`

## 5. `selectedEntities` (payload formulaire, multipart)

Ligne de formulaire (extrait) :

`["PR","MAIL","PHON","CIE","ORG","ACT","CID","ADR","LOC","URL","IP","IBAN","CARD","REF","FILE","FRNIR","DT","CP"]`

## 6. `occurrences` (apres NER) - apercu structurel

Dans le HAR, le champ `occurrences` contient un objet par type d'entite, avec des tableaux de chaines (exemples d'adresses, codes postaux, etc.). Les cles `ACT`, `ADR`, `CIE`, `CID`, `CP`, `DT`, `FILE`, `FRNIR`, `IP`, `LOC`, `MAIL`, `ORG`, `PHON`, `PR`, `REF`, `URL` apparaissent selon le document.

(Detail exact depend du PDF test ; ne pas dupliquer ici de donnees metier completes issues du HAR.) 

## 7. En-tetes HTTP (echantillons API `app_calls` creation)

- `access-control-allow-origin: *`
- `content-type: application/json`
- `x-content-type-options: nosniff`
- `x-frame-options: SAMEORIGIN`
- `x-xss-protection: 1; mode=block`
- `vary: Accept-Encoding, Origin`
- `strict-transport-security` : **absent** sur l'echantillon de reponse API ci-dessus (contrairement a certaines reponses `marvin-systems.com` ou HSTS est present). A harmoniser cote `api.`.

## 8. Cles de stockage local (chunk JS `23dd382740ba647e.js`)

Cles `localStorage` exportees en clair par le bundler (ordre d'apparition dans le module) :

- `anonymizer-active-session` (`anonymizerActiveSessionStorageKey`)
- `anonymizer-blacklist` / `anonymizer-whitelist`
- `anonymizer-calls` / `anonymizer-sessions` / `anonymizer-settings`
- `anonymizer-editor-collapsed-sections` / `anonymizer-editor-recent-entities`
- `pocketbase_file-token` (`pocketbaseFileToken`)
- `pseudonymization-map` (`pseudonymizationMapStorageKey`)
- `banner`, `email`, `rememberMe`, `anonymizer-session-lock-warning-dismissed`

## 9. Deux `PB_URL` distincts dans le bundle (versions de build)

Fichier `6250f374dd6933e2.js` (extrait) :

- `PB_URL` -> `https://api.marvin-systems.com`

Fichier `dc5bdeef4defe1c1.js` (extrait) :

- `PB_URL` -> `https://pb.marvin-systems.com`

Autres constantes de bundle communes a ces morceaux (non secrets par nature marketing) : `GADS_ID` = `AW-17930965111`, `GADS_CONVERSION_LABEL` = `J18QCIy39I0cEPegk-ZC`, `WEB_URL` = `https://marvin-systems.com`.

## 10. Variables d'environnement referencees cote client (noms, pas necessairement les valeurs)

Dans `6250f374dd6933e2.js` / `dc5bdeef4defe1c1.js` :

- `t.default.env.NEXT_PUBLIC_POSTHOG_URL`
- `t.default.env.BRAIN_URL`
- `t.default.env.BRAIN_AUTH_KEY`
- `t.default.env.BRAIN_AUTH_SECRET`

Recherche supplementaire (bundles `*_files/*.js`, grep `brain.`) : **aucune** URL de service `https://...brain...` inlinée dans les fichiers analyses ; seuls les noms d'environnement et les references `t.default.env.BRAIN_*` sont presents. Les valeurs doivent etre controlees sur le bundle de production (CI / inspection navigateur) pour exclure toute fuite d'un secret en clair.

## 11. PostHog (proxy sur le domaine public)

- Chargement de `https://marvin-systems.com/ph/static/posthog-recorder.js?v=1.352.0`
- En-tete d'avertissement observe sur du traffic PostHog : `x-posthog-rate-limit-warning` (dans le HAR)

## 12. Paiement (Stripe + PocketBase)

Dans le chunk (meme module que `PB_URL` / `WEB_URL`), creation de la collection `StripeSessions` cote client PocketBase, avec `customerSessionSecret` retourne (flux Customer Portal / checkout).

---

*Fin du fichier de preuves brutes. Voir [FINDINGS_PENTEST_MARVIN.md](FINDINGS_PENTEST_MARVIN.md) pour le risque par finding.*
