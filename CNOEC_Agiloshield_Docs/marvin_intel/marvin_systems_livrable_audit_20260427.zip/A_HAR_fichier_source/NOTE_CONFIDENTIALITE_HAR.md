# Note sur le fichier `marvin-systems.com.har`

## Nature du fichier

Un fichier **HAR** (HTTP Archive) enregistre les requêtes et réponses HTTP/HTTPS d’une session navigateur : URLs complètes, en-têtes, corps (y compris JSON d’API), parfois **cookies**, **paramètres `token=`** sur les URL de fichiers, et traces d’identifiants de session.

## Risques

- **Fuite** si le fichier est publié, versionné sur un dépôt public, ou envoyé par e-mail non chiffré.
- **Replay limité** : selon l’API, d’anciens jetons peuvent être révoqués — le risque principal reste la **divulgation d’infrastructure** et de **comportement applicatif**, pas forcément l’usurpation de session durable.

## Recommandation pour Marvin Systems

1. Recevoir le HAR sur un **canal confidentiel** (coffre, lien à mot de passe, S/MIME).
2. **Analyse interne** par l’équipe sécurité / développement.
3. **Ne pas** republier le HAR ; conserver une copie dans le dossier d’incident / audit.
4. Après lecture : **invalider** toute session test exposée si nécessaire et **rotater** les clés côté configuration si un secret avait été par erreur dans le bundle (cf. finding F1 — noms `BRAIN_*` côté client).

## Taille et origine (copie avril 2026)

- Fichier copié depuis le poste de l’auditeur (répertoire Téléchargements).
- Taille indicative : ~1,3 Mo (peut varier selon la session capturée).

---

*Document d’accompagnement — ne pas supprimer de l’archive transmise au client sans accord.*
