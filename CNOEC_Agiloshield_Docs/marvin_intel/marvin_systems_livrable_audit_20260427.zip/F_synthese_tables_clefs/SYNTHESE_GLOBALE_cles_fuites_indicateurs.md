# Synthèse globale — clés, fuites, indicateurs, erreurs (Marvin Systems)

**Document de travail** — avril 2026 — regroupe en un seul endroit les éléments dispersés dans `RAW_EVIDENCE`, `FINDINGS`, `MARVIN_BACKEND_DECODED`.  
**Aucun secret d’exploitation** n’est inscrit ici en clair : les *valeurs* de jetons vont **dans le HAR** ; ce fichier liste les *noms* et *natures* d’exposition.

**Niveau de preuve** : voir **`RAW_FINDINGS_2026-04-27.md`** (prouvé par HAR vs inféré vs non établi). **Important** : le NLP sur markdown **ne contredit pas** la présence de `markdownRegions` / `redactionRegions` — le détail est dans **`MARVIN_ARCHITECTURE_DECODED.md`** section 2.

---

## 1. Infrastructure et réseau

| Indice | Valeur (audit passif) |
|--------|------------------------|
| Hôte API principal | `api.marvin-systems.com` |
| Hôte legacy / second | `pb.marvin-systems.com` (double surface — finding F2) |
| IP serveur (échantillon HAR) | `51.158.124.96` (Online SAS / **Scaleway**, Paris) |
| Protocole | HTTP/2, `alt-svc` HTTP/3, compression **zstd** sur JSON |
| WAF / CDN | Non attesté de manière certaine (finding F5) |

---

## 2. Stack technique (inférée)

| Couche | Technologie |
|--------|-------------|
| Front | **Next.js** (App Router, Turbopack, RSC) |
| API / données | **PocketBase** (Go) — collections, fichiers, SSE |
| Paiement | **Stripe** (collection `StripeSessions`, Customer Portal) |
| Analytics | **PostHog** (proxy sur `marvin-systems.com/ph/`) + **Google Ads** |
| Cœur traitement | Service interne **BRAIN** (NER, post-traitement) — côté serveur |

---

## 3. Modèle de données clé (PocketBase)

| Élément | Détail |
|---------|--------|
| Collection | `app_calls` |
| `collectionId` | `pbc_614331130` |
| Exemple d’`id` d’enregistrement (session d’audit) | `7s4c4oyl576966e` (exemple, pas persistant) |
| Fichiers liés | `markdown_input_*.md`, `markdown_output_*.md`, `markdown_regions_*.json` (accès `GET` avec `?token=...`) |
| Temps réel | `POST /api/realtime` — abonnement SSE `app_calls/*` |
| Champs typiques (liste non exhaustive) | Voir `RAW_EVIDENCE` section 4 : extractor/analyzer, `tokenizedInput`, `sanitizedInput`, `occurrences`, `credits`, pseudonymes, etc. |

---

## 4. Ontologie NER (18 types)

`PR`, `MAIL`, `PHON`, `CIE`, `ORG`, `ACT`, `CID`, `ADR`, `LOC`, `URL`, `IP`, `IBAN`, `CARD`, `REF`, `FILE`, `FRNIR`, `DT`, `CP`

---

## 5. Clés et identifiants *non secrets* (marketing / public)

Ces identifiants sont **visibles côté client** par design ; le risque est surtout la **pollution** d’analytics ou l’**énumération**, pas une clé d’API serveur (finding F10).

| Nom | Rôle | Valeur (documentée) |
|-----|------|---------------------|
| `GADS_ID` | Google Ads | `AW-17930965111` |
| `GADS_CONVERSION_LABEL` | Conversion | `J18QCIy39I0cEPegk-ZC` |
| `WEB_URL` | Base site | `https://marvin-systems.com` |

**PostHog** : chargement de `.../ph/static/posthog-recorder.js` — risque d’enregistrement de session sur parcours document (F8) ; à traiter côté config / DPA.

---

## 6. Noms d’environnement exposés dans le bundle (hygiène / F1)

Références **littérales** dans le JS (noms, pas preuve de valeur en clair dans les chunks analysés) :

- `NEXT_PUBLIC_POSTHOG_URL`
- `BRAIN_URL`
- `BRAIN_AUTH_KEY`
- `BRAIN_AUTH_SECRET`

**Action** : ne jamais laisser de vrais secrets dans un bundle public ; vérifier l’absence de `NEXT_PUBLIC_*` contenant des secrets.

---

## 7. `localStorage` (clés exposées côté navigateur — F3)

Inclut notamment : `pocketbase_file-token`, `pseudonymization-map`, clés d’UI (`anonymizer-*`), `email`, `rememberMe`, etc. Liste complète : `RAW_EVIDENCE` section 8.

**Risque** : en cas de **XSS**, lecture des jetons / cartes de pseudonymisation côté poste.

---

## 8. En-têtes HTTP (exemples API)

- `Access-Control-Allow-Origin: *` (F6 — CORS ouvert)
- HSTS : **manquant** sur un échantillon d’API JSON (F7) alors que présent ailleurs sur le domaine site
- `X-Frame-Options: SAMEORIGIN`, `X-Content-Type-Options: nosniff`

---

## 9. Findings de sécurité (synthèse F1–F11)

| ID | Gravité | Titre court |
|----|---------|-------------|
| F1 | Critique | Noms d’environnement `BRAIN_*` dans le JS public |
| F2 | Haut | Deux hôtes `api` / `pb` |
| F3 | Haut | Jetons + pseudonymes en `localStorage` |
| F4 | Haut | `?edit=` + IDs observables (risque IDOR à valider) |
| F5 | Haut | IP exposée, pas de WAF/CDN évident |
| F6 | Moyen | CORS `*` |
| F7 | Moyen | HSTS / CSP hétérogènes |
| F8 | Moyen | Enregistreur PostHog sur l’anonymiseur |
| F9 | Moyen | Abonnement SSE `app_calls/*` (filtrage à valider) |
| F10 | Faible | Clés marketing (PostHog, GADS) |
| F11 | Faible | Empreinte builds / chunks |

Détail et remédiations : `FINDINGS_PENTEST_MARVIN.md` et rapports PDF dans `D_audit_securite_findings_rapports/`.

---

## 10. Fichiers sources d’enquête (hors zip ou chemin local)

- **HAR** : `A_HAR_fichier_source/marvin-systems.com.har`
- **HTML / JS offline** (si conservés par l’auditeur) : `Anonymisation de documents - ... _ Marvin Systems.html` + `*_files/*.js` — non dupliqués ici (volumineux) ; extraits cités dans `RAW_EVIDENCE`

---

## 11. Renvois vers les livrables

| Sujet | Fichier dans ce dossier |
|-------|-------------------------|
| Preuves détaillées | `B_preuves_brutes_HAR/RAW_EVIDENCE.md` |
| Architecture | `C_architecture_backend/MARVIN_BACKEND_DECODED.md` |
| Audit | `D_audit_securite_findings_rapports/*` |
| Reproductibilité / défense | `E_blueprint_defensif_reproductibilite/*` |

---

*Dernière mise à jour : avril 2026.*
